# Muhammad Waqas — Academic Research Portfolio

Vite + React + TypeScript + Tailwind static portfolio site.

## Deploy to Vercel

1. Push this folder to a new GitHub repository.
2. Go to vercel.com → "Add New Project" → import that repository.
3. Vercel auto-detects the Vite framework. Leave all settings default (Build Command: `vite build`, Output Directory: `dist`).
4. Click Deploy.

## Local development

```
npm install
npm run dev
```

## Edit content

All text (bio, thesis, research projects, education, experience, certifications) lives in one file:

`src/data/portfolioData.ts`

Edit that file, commit, and push — Vercel redeploys automatically.

## Optional: profile photo

Add a photo named `hero.png` to the `public/` folder to replace the initials placeholder in the hero section.
