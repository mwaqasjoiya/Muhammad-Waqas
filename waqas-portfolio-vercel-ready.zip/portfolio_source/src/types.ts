export interface ResearchProject {
  id: string;
  title: string;
  category: 'Thesis' | 'Financial Econometrics' | 'Equity Valuation' | 'Portfolio & Risk';
  type: 'Academic Empirical Research' | 'Applied Financial Valuation' | 'Econometric Working Paper';
  subtitle: string;
  courseOrContext?: string;
  supervisorOrFaculty?: string;
  date: string;
  abstract: string;
  researchQuestions: string[];
  datasetAndSample: {
    period: string;
    sampleSize: string;
    frequency: string;
    description: string;
    entities?: string[];
  };
  methodology: {
    techniques: string[];
    software: string[];
    modelsUsed: string[];
    equations?: string[];
  };
  keyVariables?: {
    dependent?: string[];
    independent?: string[];
    moderating?: string[];
    control?: string[];
  };
  empiricalResults: {
    summary: string;
    metrics?: { label: string; value: string; note?: string }[];
    tables?: {
      title: string;
      headers: string[];
      rows: (string | number)[][];
      note?: string;
    }[];
  };
  diagnosticTests?: {
    testName: string;
    nullHypothesis: string;
    statistic: string;
    pValue: string;
    decision: string;
    conclusion: string;
  }[];
  contributionsAndImplications: string[];
  pdfAvailable?: boolean;
  driveLink?: string;
}

export interface EducationItem {
  degree: string;
  institution: string;
  location: string;
  campus?: string;
  dates: string;
  cgpa: string;
  maxGpa: string;
  field: string;
  thesisTitle?: string;
  supervisor?: string;
  distinctions: string[];
  keyCourses?: string[];
}

export interface TeachingExperienceItem {
  role: string;
  institution: string;
  location: string;
  dates: string;
  audience: string;
  highlights: string[];
  subjects: string[];
  iconType?: string;
}

export interface ProfessionalExperienceItem {
  role: string;
  organization: string;
  location: string;
  dates: string;
  highlights: string[];
  domain: string;
  link?: string;
}

export interface CertificationItem {
  title: string;
  issuer: string;
  date: string;
  skills: string[];
  description: string;
  credentialUrl?: string;
  isUniversityAuthorized?: boolean;
}

export interface ResearchInterestCategory {
  category: string;
  description: string;
  interests: {
    name: string;
    description: string;
    keyThemes: string[];
  }[];
}
