import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { ResearchInterestsSection } from './components/ResearchInterestsSection';
import { ThesisShowcaseSection } from './components/ThesisShowcaseSection';
import { FeaturedResearchSection } from './components/FeaturedResearchSection';
import { AppliedFinanceSection } from './components/AppliedFinanceSection';
import { EconometricMethodsSection } from './components/EconometricMethodsSection';
import { EducationTimeline } from './components/EducationTimeline';
import { TeachingExperienceSection } from './components/TeachingExperienceSection';
import { ProfessionalExperienceSection } from './components/ProfessionalExperienceSection';
import { CertificationsSection } from './components/CertificationsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ResearchViewerModal } from './components/ResearchViewerModal';
import { CvViewerModal } from './components/CvViewerModal';
import { MAJOR_THESIS_PROJECT } from './data/portfolioData';
import { ResearchProject } from './types';

export default function App() {
  const [isCvModalOpen, setIsCvModalOpen] = useState<boolean>(false);
  const [selectedResearchProject, setSelectedResearchProject] = useState<ResearchProject | null>(null);

  const handleOpenThesis = () => {
    setSelectedResearchProject(MAJOR_THESIS_PROJECT);
  };

  const handleExploreResearch = () => {
    const el = document.getElementById('thesis');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans selection:bg-blue-600 selection:text-white antialiased">
      {/* Sticky Academic Navbar */}
      <Navbar
        onOpenCv={() => setIsCvModalOpen(true)}
        onOpenThesis={handleOpenThesis}
      />

      {/* Main Content Sections */}
      <main>
        {/* 1. Hero & Academic Dossier Card */}
        <HeroSection
          onOpenCv={() => setIsCvModalOpen(true)}
          onExploreResearch={handleExploreResearch}
        />

        {/* 2. Research Profile & Orientation */}
        <AboutSection />

        {/* 3. Research Interests & Scientific Domains */}
        <ResearchInterestsSection />

        {/* 4. Featured Master's Thesis Showcase (Corporate Governance, ESG & ROA) */}
        <ThesisShowcaseSection
          onOpenModal={(project) => setSelectedResearchProject(project)}
        />

        {/* 5. Econometric Empirical Research Papers (PSX Equity & CAPM, Multi-Factor Risk) */}
        <FeaturedResearchSection
          onOpenModal={(project) => setSelectedResearchProject(project)}
        />

        {/* 6. Applied Corporate Finance & DCF Valuations (with Live Sensitivity Simulator) */}
        <AppliedFinanceSection
          onOpenModal={(project) => setSelectedResearchProject(project)}
        />

        {/* 7. Research Methods, Econometrics & STATA Terminal */}
        <EconometricMethodsSection />

        {/* 8. Education & Academic Distinctions Timeline */}
        <EducationTimeline />

        {/* 9. Teaching & Mentoring Experience */}
        <TeachingExperienceSection />

        {/* 10. Professional Experience & Industry Background */}
        <ProfessionalExperienceSection />

        {/* 11. Certifications & Academic Seminars */}
        <CertificationsSection />

        {/* 12. PhD Supervision Inquiries & Contact Form */}
        <ContactSection />
      </main>

      {/* Academic Footer */}
      <Footer onOpenCv={() => setIsCvModalOpen(true)} />

      {/* Interactive In-Depth Research Paper Modal */}
      <ResearchViewerModal
        project={selectedResearchProject}
        onClose={() => setSelectedResearchProject(null)}
      />

      {/* Printable & Exportable Academic CV Modal */}
      <CvViewerModal
        isOpen={isCvModalOpen}
        onClose={() => setIsCvModalOpen(false)}
      />
    </div>
  );
}
