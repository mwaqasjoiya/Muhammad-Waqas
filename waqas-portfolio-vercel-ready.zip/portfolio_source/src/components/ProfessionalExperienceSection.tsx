import React from 'react';
import { Briefcase, Calendar, MapPin, CheckCircle2, ExternalLink, ShieldCheck } from 'lucide-react';
import { PROFESSIONAL_EXPERIENCE_DATA } from '../data/portfolioData';

export const ProfessionalExperienceSection: React.FC = () => {
  return (
    <section id="experience" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-slate-600 mb-2">
            <Briefcase className="w-4 h-4" />
            <span>Applied Industry Experience</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Professional Experience & Industry Background
          </h2>
          <div className="w-16 h-1 bg-slate-700 mt-3.5 mb-4"></div>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Hands-on professional roles in corporate budgeting, international equity buyback tracking, and public fiscal audit compliance.
          </p>
        </div>

        {/* Experience List */}
        <div className="space-y-6 text-left">
          {PROFESSIONAL_EXPERIENCE_DATA.map((job, idx) => (
            <div
              key={idx}
              className="bg-slate-50 rounded-xl border border-slate-200 p-6 sm:p-8 hover:border-slate-300 transition-all"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 pb-4 border-b border-slate-200">
                <div>
                  <span className="text-[11px] font-mono uppercase font-bold text-blue-700">
                    {job.domain}
                  </span>
                  <h3 className="font-serif-academic text-xl font-bold text-slate-900 mt-0.5">
                    {job.role}
                  </h3>
                  <div className="text-sm font-semibold text-slate-700">
                    {job.organization} <span className="font-normal text-slate-500">• {job.location}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-3 text-xs font-mono text-slate-500">
                  <div className="flex items-center space-x-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{job.dates}</span>
                  </div>
                  {job.link && (
                    <a
                      href={job.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1 rounded bg-white border border-slate-200 text-blue-700 hover:text-blue-900 flex items-center space-x-1"
                    >
                      <span>Verification Drive</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </div>

              <div className="mt-4 space-y-2 text-xs sm:text-sm text-slate-700">
                {job.highlights.map((hl, hIdx) => (
                  <div key={hIdx} className="flex items-start space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-slate-500 mt-0.5 shrink-0" />
                    <span className="leading-relaxed">{hl}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
