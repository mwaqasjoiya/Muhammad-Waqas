import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2, MessageSquare, GraduationCap, Globe, Clock, ShieldCheck, Sparkles } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const ContactSection: React.FC = () => {
  const [inquiryType, setInquiryType] = useState<string>('PhD Supervision');
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [institution, setInstitution] = useState<string>('');
  const [message, setMessage] = useState<string>(
    'Dear Muhammad Waqas,\n\nI have reviewed your academic research portfolio in corporate governance, financial econometrics, and equity valuation. I would like to discuss potential doctoral supervision / research opportunities...'
  );
  const [submitted, setSubmitted] = useState<boolean>(false);

  const inquiryTemplates: Record<string, string> = {
    'PhD Supervision':
      'Dear Muhammad Waqas,\n\nI am contacting you regarding potential PhD opportunities / doctoral supervision in our department. We are interested in your research in corporate governance, ESG moderation, and panel econometrics...',
    'Research Assistantship':
      'Dear Muhammad Waqas,\n\nWe have an open Research Assistant / Pre-doctoral fellowship position and would like to discuss your empirical econometrics experience in STATA and panel data...',
    'Academic Collaboration':
      'Dear Muhammad Waqas,\n\nI would like to discuss a potential research collaboration or working paper review on emerging market financial econometrics and ESG reporting...',
    'General Inquiry':
      'Dear Muhammad Waqas,\n\nI would like to connect regarding your academic research profile and econometric modeling...'
  };

  const handleInquiryChange = (type: string) => {
    setInquiryType(type);
    setMessage(inquiryTemplates[type] || '');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Generate mailto link
    const subject = encodeURIComponent(`[Academic Inquiry - ${inquiryType}] ${institution ? `${institution} - ` : ''}${name}`);
    const body = encodeURIComponent(`From: ${name} (${email})\nInstitution: ${institution}\nInquiry Type: ${inquiryType}\n\n${message}`);
    
    // Trigger user's default email client
    window.location.href = `mailto:${PERSONAL_INFO.email}?subject=${subject}&body=${body}`;
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 bg-slate-900 text-white border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-blue-400 mb-2">
            <Mail className="w-4 h-4" />
            <span>Academic Inquiries & Opportunities</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-white tracking-tight">
            PhD Supervision, Research & Contact
          </h2>
          <div className="w-16 h-1 bg-blue-500 mt-3.5 mb-4"></div>
          <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
            I am actively seeking <strong className="text-white">fully funded PhD positions, research assistantships, and academic collaborations</strong> in Finance, Accounting, and Applied Economics globally.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 text-left">
          
          {/* Left Column: Direct Scholar Details (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="bg-slate-950 p-6 sm:p-8 rounded-2xl border border-slate-800 space-y-6">
              <div>
                <h3 className="font-serif-academic font-bold text-xl text-white">
                  Direct Scholar Contact
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Prospective PhD supervisors and academic committees may reach out directly via email or phone.
                </p>
              </div>

              <div className="space-y-4 text-xs sm:text-sm">
                
                <a
                  href={`mailto:${PERSONAL_INFO.email}`}
                  className="flex items-start space-x-3.5 p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-blue-500 hover:bg-slate-900 transition-all group"
                >
                  <div className="w-9 h-9 rounded-lg bg-blue-950 border border-blue-800/60 flex items-center justify-center text-blue-400 shrink-0 group-hover:scale-105 transition-transform">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Primary Academic Email</div>
                    <div className="font-semibold text-slate-100 group-hover:text-blue-300 transition-colors">
                      {PERSONAL_INFO.email}
                    </div>
                  </div>
                </a>

                <div className="flex items-start space-x-3.5 p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                  <div className="w-9 h-9 rounded-lg bg-slate-850 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Telephone / WhatsApp</div>
                    <div className="font-semibold text-slate-200">{PERSONAL_INFO.phone}</div>
                  </div>
                </div>

                <div className="flex items-start space-x-3.5 p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                  <div className="w-9 h-9 rounded-lg bg-slate-850 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Institutional Location</div>
                    <div className="font-semibold text-slate-200">{PERSONAL_INFO.address}</div>
                    <div className="text-[11px] text-slate-400">Institute of Business Administration (IBA), Punjab University</div>
                  </div>
                </div>

                <a
                  href={PERSONAL_INFO.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start space-x-3.5 p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-blue-500 transition-all group"
                >
                  <div className="w-9 h-9 rounded-lg bg-blue-950 border border-blue-800/60 flex items-center justify-center text-blue-400 shrink-0">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Professional LinkedIn Profile</div>
                    <div className="font-semibold text-blue-300 group-hover:underline">
                      linkedin.com/in/muhammad-waqas
                    </div>
                  </div>
                </a>

              </div>

              <div className="pt-4 border-t border-slate-800 text-xs text-slate-400 space-y-1 font-mono">
                <div>• Timezone: PKT (UTC+5)</div>
                <div>• Target Enrollment: Fall 2026 / Spring 2027 PhD Cycles</div>
                <div>• Research Proposal available upon request</div>
              </div>
            </div>

          </div>

          {/* Right Column: Academic Inquiry Form (7 cols) */}
          <div className="lg:col-span-7">
            
            <div className="bg-slate-950 p-6 sm:p-8 rounded-2xl border border-slate-800">
              
              <h3 className="font-serif-academic font-bold text-xl text-white mb-2">
                Send an Academic Inquiry
              </h3>
              <p className="text-xs text-slate-400 mb-6">
                Select an inquiry topic below to load a tailored communication template.
              </p>

              {/* Inquiry Type Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
                {['PhD Supervision', 'Research Assistantship', 'Academic Collaboration', 'General Inquiry'].map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => handleInquiryChange(type)}
                    className={`py-2 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      inquiryType === type
                        ? 'bg-blue-600 text-white font-bold'
                        : 'bg-slate-900 text-slate-300 border border-slate-800 hover:bg-slate-850'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>

              {submitted ? (
                <div className="p-6 bg-emerald-950/60 border border-emerald-800/80 rounded-xl text-center space-y-3">
                  <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                  <div className="font-serif-academic font-bold text-lg text-white">
                    Inquiry Email Client Launched
                  </div>
                  <p className="text-xs text-slate-300 max-w-md mx-auto">
                    Your email client has been prepared with your inquiry to <strong className="text-white">{PERSONAL_INFO.email}</strong>. If your email client didn't open automatically, you can send an email directly to this address.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="px-4 py-1.5 rounded bg-slate-900 text-xs font-semibold text-slate-300 hover:text-white border border-slate-800"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono uppercase font-semibold text-slate-300 mb-1.5">
                        Your Name / Title *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Prof. / Dr. / Chair Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono uppercase font-semibold text-slate-300 mb-1.5">
                        Your Email *
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="academic@university.edu"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase font-semibold text-slate-300 mb-1.5">
                      University / Academic Department / Institution
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Department of Finance, University Name"
                      value={institution}
                      onChange={(e) => setInstitution(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase font-semibold text-slate-300 mb-1.5">
                      Message / Academic Opportunity Details *
                    </label>
                    <textarea
                      required
                      rows={5}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-blue-500 leading-relaxed font-sans"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 px-6 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm flex items-center justify-center space-x-2 transition-colors cursor-pointer shadow-lg shadow-blue-950"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Academic Inquiry to Muhammad Waqas</span>
                  </button>

                </form>
              )}

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
