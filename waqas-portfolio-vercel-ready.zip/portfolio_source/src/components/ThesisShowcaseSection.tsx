import React, { useState } from 'react';
import { Award, BookOpen, CheckCircle, Database, FileText, ArrowRight, ShieldCheck, TrendingUp, Sparkles, Layers, Sliders, ExternalLink, HelpCircle } from 'lucide-react';
import { MAJOR_THESIS_PROJECT } from '../data/portfolioData';

interface ThesisShowcaseSectionProps {
  onOpenModal: (project: typeof MAJOR_THESIS_PROJECT) => void;
}

export const ThesisShowcaseSection: React.FC<ThesisShowcaseSectionProps> = ({ onOpenModal }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'framework' | 'econometrics' | 'diagnostics'>('overview');

  return (
    <section id="thesis" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-blue-700 mb-2">
            <Award className="w-4 h-4 text-amber-500" />
            <span>Featured Master's Research</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Master's Thesis Research Project
          </h2>
          <div className="w-16 h-1 bg-blue-700 mt-3.5 mb-4"></div>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            An empirical investigation into corporate governance, institutional ownership, and sustainability reporting in Pakistan's non-financial listed sector.
          </p>
        </div>

        {/* Hero Card for the Thesis */}
        <div className="bg-[#0F172A] rounded-2xl text-white border border-slate-800 shadow-xl overflow-hidden mb-10 text-left">
          
          <div className="p-6 sm:p-8 lg:p-10">
            {/* Top metadata tags */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-6 border-b border-slate-800">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 rounded bg-blue-900/80 border border-blue-700/60 text-blue-200 text-xs font-semibold">
                  Master of Business Administration (MBA 1.5) Thesis
                </span>
                <span className="px-3 py-1 rounded bg-amber-950/80 border border-amber-600/60 text-amber-300 text-xs font-semibold flex items-center space-x-1.5">
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  <span>Awarded 2nd Position in Master's Final Thesis</span>
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono">
                Institute of Business Administration (IBA), University of the Punjab
              </div>
            </div>

            {/* Title & Supervisor */}
            <div className="mt-6">
              <h3 className="font-serif-academic text-2xl sm:text-3xl lg:text-4xl font-bold text-white leading-tight">
                {MAJOR_THESIS_PROJECT.title}
              </h3>
              <p className="mt-3 text-sm sm:text-base text-blue-300 font-medium flex items-center space-x-2">
                <span>{MAJOR_THESIS_PROJECT.supervisorOrFaculty}</span>
                <span className="text-slate-500">•</span>
                <span>Date: June 2026</span>
              </p>
            </div>

            {/* Quick Metrics Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 my-8 p-4 bg-slate-900/90 rounded-xl border border-slate-800">
              <div>
                <div className="text-[10px] uppercase font-mono text-slate-400">Target Sample</div>
                <div className="text-sm sm:text-base font-bold text-white mt-0.5">PSX Non-Financial</div>
                <div className="text-[11px] text-slate-400">Listed Corporations</div>
              </div>
              <div>
                <div className="text-[10px] uppercase font-mono text-slate-400">Dependent Variable</div>
                <div className="text-sm sm:text-base font-bold text-blue-400 mt-0.5">ROA (Return on Assets)</div>
                <div className="text-[11px] text-slate-400">Financial Performance</div>
              </div>
              <div>
                <div className="text-[10px] uppercase font-mono text-slate-400">Moderating Channel</div>
                <div className="text-sm sm:text-base font-bold text-emerald-400 mt-0.5">Sustainability / ESG</div>
                <div className="text-[11px] text-slate-400">Disclosure Index</div>
              </div>
              <div>
                <div className="text-[10px] uppercase font-mono text-slate-400">Primary Software</div>
                <div className="text-sm sm:text-base font-bold text-purple-400 mt-0.5">STATA 15</div>
                <div className="text-[11px] text-slate-400">Panel Regressions (FE/RE)</div>
              </div>
            </div>

            {/* Navigation Tabs Inside Thesis Showcase */}
            <div className="flex flex-wrap border-b border-slate-800 gap-2 mb-6">
              {[
                { id: 'overview', label: '1. Executive Abstract & Objectives' },
                { id: 'framework', label: '2. Conceptual Framework & Variables' },
                { id: 'econometrics', label: '3. Econometric Model Specification' },
                { id: 'diagnostics', label: '4. Diagnostics & Empirical Findings' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`pb-3 px-3 text-xs sm:text-sm font-semibold transition-all border-b-2 cursor-pointer ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-400'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab 1: Overview */}
            {activeTab === 'overview' && (
              <div className="space-y-6 text-slate-300 text-sm sm:text-base leading-relaxed">
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-wider text-slate-200 font-mono mb-2">
                    Research Problem & Context
                  </h4>
                  <p className="font-light text-slate-300">
                    {MAJOR_THESIS_PROJECT.abstract}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div className="bg-slate-900/60 p-4 rounded-lg border border-slate-800">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-blue-400 mb-2 font-mono">
                      Core Research Questions
                    </h5>
                    <ul className="space-y-2 text-xs text-slate-300">
                      {MAJOR_THESIS_PROJECT.researchQuestions.map((q, idx) => (
                        <li key={idx} className="flex items-start space-x-2">
                          <span className="text-blue-500 font-bold shrink-0">Q{idx + 1}:</span>
                          <span>{q}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-slate-900/60 p-4 rounded-lg border border-slate-800">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-2 font-mono">
                      Theoretical Foundations
                    </h5>
                    <ul className="space-y-2 text-xs text-slate-300">
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />
                        <span><strong>Agency Theory (Jensen & Meckling, 1976):</strong> Independent audit committees reduce managerial opportunistic behavior.</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />
                        <span><strong>Stakeholder Theory (Freeman, 1984):</strong> Transparent ESG reporting mitigates information asymmetry for stakeholders.</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />
                        <span><strong>Resource Dependence Theory:</strong> Diverse board networks facilitate critical capital allocation in volatile markets.</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Conceptual Framework Diagram */}
            {activeTab === 'framework' && (
              <div className="space-y-6">
                <div className="bg-slate-950 p-6 rounded-xl border border-slate-800">
                  <div className="text-xs font-mono uppercase text-slate-400 text-center mb-6">
                    CONCEPTUAL FRAMEWORK: THEORETICAL TRANSMISSION PATHWAYS
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                    
                    {/* Independent Variables */}
                    <div className="md:col-span-4 bg-slate-900 p-4 rounded-lg border border-blue-900/60 space-y-3">
                      <div className="text-xs font-bold uppercase tracking-wider text-blue-400 font-mono flex items-center space-x-1.5">
                        <ShieldCheck className="w-4 h-4" />
                        <span>Independent Variables</span>
                      </div>
                      <div className="space-y-2 text-xs">
                        <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                          <div className="font-semibold text-slate-200">Audit Committee Independence</div>
                          <div className="text-[11px] text-slate-400">% Independent Directors on Audit Committee</div>
                        </div>
                        <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                          <div className="font-semibold text-slate-200">Institutional Ownership</div>
                          <div className="text-[11px] text-slate-400">% Shares held by institutional investors</div>
                        </div>
                      </div>
                    </div>

                    {/* Moderating Variable (Center) */}
                    <div className="md:col-span-4 flex flex-col items-center justify-center space-y-3">
                      <div className="w-full bg-emerald-950/80 p-4 rounded-lg border border-emerald-700/60 text-center space-y-1">
                        <div className="text-xs font-bold uppercase tracking-wider text-emerald-300 font-mono flex items-center justify-center space-x-1.5">
                          <Sparkles className="w-4 h-4 text-emerald-400" />
                          <span>Moderating Variable</span>
                        </div>
                        <div className="font-semibold text-white text-sm">Sustainability / ESG Reporting</div>
                        <div className="text-[11px] text-emerald-200/80">Corporate ESG Disclosure Index</div>
                      </div>

                      <div className="text-center text-xs text-slate-400 italic">
                        ↓ Direct & Moderated Interaction Channels
                      </div>
                    </div>

                    {/* Dependent Variable */}
                    <div className="md:col-span-4 bg-slate-900 p-4 rounded-lg border border-purple-900/60 space-y-3">
                      <div className="text-xs font-bold uppercase tracking-wider text-purple-400 font-mono flex items-center space-x-1.5">
                        <TrendingUp className="w-4 h-4" />
                        <span>Dependent Variable</span>
                      </div>
                      <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-xs">
                        <div className="font-semibold text-slate-200">Corporate Financial Performance</div>
                        <div className="text-sm font-mono text-purple-300 font-bold mt-1">Return on Assets (ROA)</div>
                        <div className="text-[10px] text-slate-400 mt-0.5">Net Income / Total Assets</div>
                      </div>
                    </div>

                  </div>

                  {/* Control Variables Bar */}
                  <div className="mt-6 pt-4 border-t border-slate-800 bg-slate-900/40 p-3 rounded-lg text-xs">
                    <span className="font-mono text-slate-400 uppercase font-semibold">Control Variables: </span>
                    <span className="text-slate-300">Firm Size (ln Total Assets) • Financial Leverage (Total Debt / Assets) • Liquidity (Current Ratio) • Firm Age</span>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 3: Econometric Specification */}
            {activeTab === 'econometrics' && (
              <div className="space-y-6">
                <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 font-mono text-xs sm:text-sm text-blue-300 overflow-x-auto">
                  <div className="text-slate-400 text-xs uppercase mb-2">Panel Econometric Model:</div>
                  <div className="text-emerald-400 font-bold py-2 text-sm sm:text-base border-y border-slate-800">
                    ROA_it = β_0 + β_1(AuditIndep_it) + β_2(InstOwn_it) + β_3(ESG_it) + β_4(Gov_it × ESG_it) + γ Controls_it + μ_i + ε_it
                  </div>
                  <div className="text-slate-400 text-xs mt-3 space-y-1">
                    <div>• i = Listed firm identifier (i = 1, ..., N)</div>
                    <div>• t = Time period (t = 1, ..., T)</div>
                    <div>• μ_i = Unobserved firm-specific time-invariant fixed effect</div>
                    <div>• ε_it = Idiosyncratic disturbance error term</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-300">
                  <div className="bg-slate-900/70 p-4 rounded-lg border border-slate-800 space-y-2">
                    <div className="font-bold text-white font-mono uppercase text-[11px]">STATA Execution Commands</div>
                    <div className="bg-slate-950 p-2.5 rounded font-mono text-slate-300 text-[11px] space-y-1">
                      <div><span className="text-blue-400">xtset</span> company_id year</div>
                      <div><span className="text-blue-400">xtreg</span> roa audit_indep inst_own esg gov_esg size lev liq, <span className="text-amber-400">fe</span></div>
                      <div><span className="text-blue-400">estimates store</span> fixed</div>
                      <div><span className="text-blue-400">xtreg</span> roa audit_indep inst_own esg gov_esg size lev liq, <span className="text-amber-400">re</span></div>
                      <div><span className="text-blue-400">hausman</span> fixed .</div>
                    </div>
                  </div>

                  <div className="bg-slate-900/70 p-4 rounded-lg border border-slate-800 space-y-2">
                    <div className="font-bold text-white font-mono uppercase text-[11px]">Model Selection Strategy</div>
                    <p className="text-slate-300 leading-relaxed">
                      The Hausman test evaluates whether unique errors are correlated with the regressors (Cov(μ_i, X_it) = 0). If rejected, the Fixed Effects (Within) estimator is selected to eliminate time-invariant omitted variable bias.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 4: Diagnostics & Findings */}
            {activeTab === 'diagnostics' && (
              <div className="space-y-6">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border border-slate-800 rounded-lg overflow-hidden">
                    <thead className="bg-slate-900 text-slate-300 uppercase font-mono">
                      <tr>
                        <th className="p-3">Diagnostic Check</th>
                        <th className="p-3">Econometric Purpose</th>
                        <th className="p-3">Decision Rule</th>
                        <th className="p-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 bg-slate-950 text-slate-300">
                      <tr>
                        <td className="p-3 font-semibold text-white">Multicollinearity (VIF)</td>
                        <td className="p-3">Verifies lack of high collinearity between ESG, size, and governance</td>
                        <td className="p-3">VIF &lt; 5.0</td>
                        <td className="p-3 text-emerald-400 font-bold">Passed (Reliable SEs)</td>
                      </tr>
                      <tr>
                        <td className="p-3 font-semibold text-white">Heteroskedasticity Test</td>
                        <td className="p-3">Checks for non-constant variance in cross-sectional error terms</td>
                        <td className="p-3">Modified Wald / Breusch-Pagan</td>
                        <td className="p-3 text-emerald-400 font-bold">Clustered SEs Validated</td>
                      </tr>
                      <tr>
                        <td className="p-3 font-semibold text-white">Serial Autocorrelation</td>
                        <td className="p-3">Tests for first-order serial correlation in panel residuals</td>
                        <td className="p-3">Wooldridge Test (p &gt; 0.05)</td>
                        <td className="p-3 text-emerald-400 font-bold">Residual Independence</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div className="bg-slate-900/80 p-4 rounded-lg border border-slate-800 text-xs text-slate-300 space-y-2">
                  <div className="font-bold text-white font-mono uppercase text-[11px]">Key Empirical Findings:</div>
                  <p>
                    1. <strong>Audit Committee Independence:</strong> Strong positive correlation with ROA, reflecting effective board monitoring of operational expenses.
                  </p>
                  <p>
                    2. <strong>Institutional Ownership:</strong> Institutional blocks serve as active disciplinary agents, aligning management incentives with equity returns.
                  </p>
                  <p>
                    3. <strong>ESG Moderation:</strong> Moderating interaction term is positive and statistically significant, confirming that non-financial transparency amplifies governance efficiency in Pakistan's emerging equity market.
                  </p>
                </div>
              </div>
            )}

            {/* Bottom Action */}
            <div className="mt-8 pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="text-xs text-slate-400">
                Full thesis empirical methodology and STATA regression models available upon academic request.
              </div>
              <button
                onClick={() => onOpenModal(MAJOR_THESIS_PROJECT)}
                className="px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center space-x-2 transition-colors cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                <span>View Complete Thesis Dossier</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
