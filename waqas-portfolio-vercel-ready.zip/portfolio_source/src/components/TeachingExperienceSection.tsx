import React from 'react';
import { BookOpen, Users, GraduationCap, Calendar, CheckCircle2, Award, HeartHandshake, Sparkles } from 'lucide-react';
import { TEACHING_EXPERIENCE_DATA } from '../data/portfolioData';

export const TeachingExperienceSection: React.FC = () => {
  return (
    <section id="teaching" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-blue-700 mb-2">
            <Users className="w-4 h-4" />
            <span>Academic Engagement & Pedagogy</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Teaching & Mentoring Experience
          </h2>
          <div className="w-16 h-1 bg-blue-700 mt-3.5 mb-4"></div>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Demonstrated commitment to academic instruction, econometric mentoring, software workshops (STATA/SPSS), and collegiate teaching.
          </p>
        </div>

        {/* Teaching Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
          {TEACHING_EXPERIENCE_DATA.map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 pb-4 border-b border-slate-100 mb-4">
                  <span className="px-2.5 py-0.5 rounded text-[11px] font-mono font-bold bg-blue-50 text-blue-800 border border-blue-200">
                    {item.dates}
                  </span>
                  <span className="text-xs text-slate-500 font-mono">{item.location}</span>
                </div>

                <h3 className="font-serif-academic text-xl font-bold text-slate-900 leading-snug">
                  {item.role}
                </h3>
                <div className="text-sm font-semibold text-blue-900 mt-1">
                  {item.institution}
                </div>
                <div className="text-xs text-slate-500 mt-0.5 mb-4 font-mono">
                  Audience: {item.audience}
                </div>

                {/* Highlights */}
                <div className="space-y-2.5 text-xs sm:text-sm text-slate-700">
                  {item.highlights.map((hl, hIdx) => (
                    <div key={hIdx} className="flex items-start space-x-2">
                      <CheckCircle2 className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                      <span className="leading-relaxed">{hl}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Subjects / Tools Badge Bar */}
              <div className="mt-6 pt-4 border-t border-slate-100">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-2">
                  Instructional Domains & Tools
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {item.subjects.map((sub, sIdx) => (
                    <span
                      key={sIdx}
                      className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[11px] font-medium"
                    >
                      {sub}
                    </span>
                  ))}
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
