import React, { useState } from 'react';
import { ArrowRight, Download, FileText, Mail, Award, BookOpen, BarChart3, CheckCircle2, Globe, Sparkles } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface HeroSectionProps {
  onOpenCv: () => void;
  onExploreResearch: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenCv, onExploreResearch }) => {
  const [imgError, setImgError] = useState(false);

  return (
    <section
      id="hero"
      className="relative pt-28 pb-16 lg:pt-36 lg:pb-24 bg-[#0A1120] text-white overflow-hidden border-b border-slate-800"
    >
      {/* Background Architectural Grid Accent */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />

      {/* Subtle Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-10 right-10 w-72 h-72 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Academic Presentation */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Top Academic Tag */}
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-950/80 border border-blue-800/60 text-blue-300 text-xs font-semibold tracking-wide">
              <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
              <span>Prospective PhD Researcher • Finance, Accounting & Economics</span>
            </div>

            {/* Main Name & Title */}
            <div>
              <h1 className="font-serif-academic text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-none">
                {PERSONAL_INFO.name}
              </h1>
              <p className="mt-3 text-lg sm:text-xl font-medium text-blue-200/90 tracking-wide font-sans">
                Finance Researcher <span className="text-slate-500 mx-1">|</span> Corporate Governance <span className="text-slate-500 mx-1">|</span> Financial Econometrics <span className="text-slate-500 mx-1">|</span> Empirical Finance
              </p>
            </div>

            {/* Concise Research Orientation Narrative */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl font-light">
              Master of Business Administration (Finance) graduate from the <strong className="text-white font-medium">Institute of Business Administration (IBA), University of the Punjab</strong>. Specializing in panel-data econometrics in <strong className="text-white font-medium">STATA</strong>, board-level corporate governance mechanisms, ESG/sustainability moderation, asset pricing, and empirical DCF valuations of emerging-market equities.
            </p>

            {/* Key Academic Distinctions Chips */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              <div className="flex items-center space-x-2.5 bg-slate-900/80 border border-slate-800 p-2.5 rounded-lg">
                <Award className="w-5 h-5 text-amber-400 shrink-0" />
                <div className="text-xs">
                  <div className="font-semibold text-slate-200">1st Position</div>
                  <div className="text-slate-400">Managerial Economics Distinction</div>
                </div>
              </div>

              <div className="flex items-center space-x-2.5 bg-slate-900/80 border border-slate-800 p-2.5 rounded-lg">
                <Award className="w-5 h-5 text-blue-400 shrink-0" />
                <div className="text-xs">
                  <div className="font-semibold text-slate-200">2nd Position</div>
                  <div className="text-slate-400">Master's Final Research Thesis</div>
                </div>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="pt-3 flex flex-wrap items-center gap-3.5">
              <button
                id="hero-explore-btn"
                onClick={onExploreResearch}
                className="inline-flex items-center justify-center space-x-2 px-6 py-3.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm transition-all shadow-lg shadow-blue-900/30 group cursor-pointer"
              >
                <span>Explore My Research</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                id="hero-cv-btn"
                onClick={onOpenCv}
                className="inline-flex items-center justify-center space-x-2 px-5 py-3.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm transition-all shadow-sm cursor-pointer"
              >
                <FileText className="w-4 h-4 text-blue-400" />
                <span>Academic CV / Resume</span>
              </button>

              <a
                id="hero-contact-btn"
                href="#contact"
                className="inline-flex items-center justify-center space-x-2 px-5 py-3.5 rounded-lg bg-transparent hover:bg-slate-800/80 text-slate-300 hover:text-white border border-slate-700 font-medium text-sm transition-all"
              >
                <Mail className="w-4 h-4 text-slate-400" />
                <span>PhD Opportunities</span>
              </a>
            </div>

            {/* Quick Credentials / Verification Links Bar */}
            <div className="pt-4 border-t border-slate-800/80 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-slate-400">
              <div className="flex items-center space-x-1.5">
                <Globe className="w-3.5 h-3.5 text-blue-400" />
                <span>Lahore, Pakistan</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>STATA 15 & SPSS Certified</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Oxford Saïd ESG Certified</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>English C1 Academic Proficiency</span>
              </div>
            </div>
          </div>

          {/* Right Column: High-End Scholar Profile Card */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="w-full max-w-md bg-slate-900/90 rounded-2xl border border-slate-800 shadow-2xl p-6 relative overflow-hidden backdrop-blur-sm">
              
              {/* Subtle top header band */}
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800 text-xs">
                <span className="font-mono text-slate-400">ACADEMIC DOSSIER • 2026</span>
                <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800/60 font-mono text-[10px] uppercase tracking-wider font-semibold">
                  PhD Applicant
                </span>
              </div>

              {/* Portrait Presentation */}
              <div className="relative mb-5 rounded-xl overflow-hidden bg-slate-950 border border-slate-800 aspect-[4/3] flex items-center justify-center group">
                {!imgError ? (
                  <img
                    src="/hero.png"
                    alt="Muhammad Waqas - Finance Researcher"
                    onError={() => setImgError(true)}
                    className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-slate-900 to-blue-950">
                    <div className="w-20 h-20 rounded-full bg-blue-900/60 border-2 border-blue-500/40 flex items-center justify-center text-3xl font-serif font-bold text-white mb-3 shadow-inner">
                      MW
                    </div>
                    <div className="font-serif-academic font-bold text-xl text-white">Muhammad Waqas</div>
                    <div className="text-xs text-blue-300 mt-1">Finance Researcher & Econometrician</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">IBA University of the Punjab</div>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent pointer-events-none" />
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-[11px] text-slate-200">
                  <span className="bg-slate-900/90 px-2.5 py-1 rounded backdrop-blur-md border border-slate-700/60 font-medium">
                    📍 Lahore, Pakistan
                  </span>
                  <span className="bg-blue-900/90 px-2.5 py-1 rounded backdrop-blur-md border border-blue-700/60 font-medium text-blue-200">
                    IBA Punjab University
                  </span>
                </div>
              </div>

              {/* Research Focus Matrix Inside Card */}
              <div className="space-y-3">
                <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
                  <BarChart3 className="w-3.5 h-3.5 text-blue-400" />
                  <span>Primary Research Metrics & Methods</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-left">
                  <div className="bg-slate-950/60 border border-slate-800 p-2.5 rounded-lg">
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Master's Thesis</div>
                    <div className="text-xs font-semibold text-slate-200 mt-0.5">Corporate Governance</div>
                    <div className="text-[10px] text-blue-400 mt-0.5">ROA & ESG Moderation</div>
                  </div>
                  
                  <div className="bg-slate-950/60 border border-slate-800 p-2.5 rounded-lg">
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Econometrics</div>
                    <div className="text-xs font-semibold text-slate-200 mt-0.5">Panel Data & CAPM</div>
                    <div className="text-[10px] text-emerald-400 mt-0.5">Fixed/Random Effects</div>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800 p-2.5 rounded-lg">
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Valuation Models</div>
                    <div className="text-xs font-semibold text-slate-200 mt-0.5">3-Statement FCFF DCF</div>
                    <div className="text-[10px] text-amber-400 mt-0.5">OGDCL, FCEPL, NFL</div>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800 p-2.5 rounded-lg">
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Software Stack</div>
                    <div className="text-xs font-semibold text-slate-200 mt-0.5">STATA 15 • SPSS</div>
                    <div className="text-[10px] text-purple-400 mt-0.5">Excel • Zotero • Mendeley</div>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={onOpenCv}
                    className="w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center justify-center space-x-2 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5 text-blue-400" />
                    <span>Download Comprehensive Academic Dossier</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
