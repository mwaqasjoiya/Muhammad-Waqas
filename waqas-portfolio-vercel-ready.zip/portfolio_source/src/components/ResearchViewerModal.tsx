import React, { useState } from 'react';
import { X, BookOpen, FileText, CheckCircle2, Award, Download, ExternalLink, Table2, Layers, Cpu, Compass } from 'lucide-react';
import { ResearchProject } from '../types';

interface ResearchViewerModalProps {
  project: ResearchProject | null;
  onClose: () => void;
}

export const ResearchViewerModal: React.FC<ResearchViewerModalProps> = ({ project, onClose }) => {
  if (!project) return null;

  const [activeTab, setActiveTab] = useState<'abstract' | 'methodology' | 'results' | 'diagnostics' | 'implications'>('abstract');

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] text-left">
        
        {/* Header Bar */}
        <div className="bg-[#0F172A] text-white p-5 sm:p-6 flex items-start justify-between gap-4 border-b border-slate-800 shrink-0">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded bg-blue-900 text-blue-200 text-xs font-mono font-semibold">
                {project.type}
              </span>
              <span className="px-2.5 py-0.5 rounded bg-slate-800 text-slate-300 text-xs font-mono">
                {project.courseOrContext || project.category}
              </span>
            </div>
            <h3 className="font-serif-academic text-xl sm:text-2xl font-bold text-white leading-tight">
              {project.title}
            </h3>
            <p className="text-xs text-blue-300 font-mono">
              {project.supervisorOrFaculty} • {project.date}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 flex flex-wrap gap-2 shrink-0">
          {[
            { id: 'abstract', label: 'Overview & Abstract' },
            { id: 'methodology', label: 'Data & Methodology' },
            { id: 'results', label: 'Empirical Results & Tables' },
            { id: 'diagnostics', label: 'Diagnostic Checks' },
            { id: 'implications', label: 'Implications & Contributions' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-3 px-3 text-xs font-semibold font-mono uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'border-blue-700 text-blue-800 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Modal Body Content (Scrollable) */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 text-slate-700 text-sm leading-relaxed">
          
          {/* Tab 1: Abstract */}
          {activeTab === 'abstract' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono mb-2">
                  Academic Abstract & Research Context
                </h4>
                <p className="text-slate-800 text-base leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-200 font-serif-academic italic">
                  "{project.abstract}"
                </p>
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono mb-3">
                  Core Research Questions
                </h4>
                <div className="space-y-2">
                  {project.researchQuestions.map((q, idx) => (
                    <div key={idx} className="flex items-start space-x-3 bg-white p-3 rounded-lg border border-slate-200">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span className="text-slate-800 font-medium">{q}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Methodology */}
          {activeTab === 'methodology' && (
            <div className="space-y-6">
              <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 font-mono">
                  Dataset Structure & Sampling
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="bg-white p-3 rounded border border-slate-200">
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Sample Period</div>
                    <div className="font-bold text-slate-900 mt-0.5">{project.datasetAndSample.period}</div>
                  </div>
                  <div className="bg-white p-3 rounded border border-slate-200">
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Sample Size / N</div>
                    <div className="font-bold text-slate-900 mt-0.5">{project.datasetAndSample.sampleSize}</div>
                  </div>
                  <div className="bg-white p-3 rounded border border-slate-200">
                    <div className="text-[10px] text-slate-400 uppercase font-mono">Observation Frequency</div>
                    <div className="font-bold text-slate-900 mt-0.5">{project.datasetAndSample.frequency}</div>
                  </div>
                </div>
                <p className="text-xs text-slate-600 pt-1">
                  {project.datasetAndSample.description}
                </p>
                {project.datasetAndSample.entities && (
                  <div className="pt-2">
                    <div className="text-[11px] font-mono text-slate-500 font-bold uppercase">Sample Entities:</div>
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {project.datasetAndSample.entities.map((e, i) => (
                        <span key={i} className="px-2 py-0.5 rounded bg-blue-50 text-blue-900 text-xs font-mono">
                          {e}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 font-mono">
                  Econometric Models & Mathematical Specifications
                </h4>
                {project.methodology.modelsUsed.map((m, idx) => (
                  <div key={idx} className="bg-slate-900 text-emerald-400 p-3.5 rounded-lg font-mono text-xs overflow-x-auto">
                    <code>{m}</code>
                  </div>
                ))}
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 font-mono mb-2">
                  Software Stack & Execution Routines
                </h4>
                <div className="flex flex-wrap gap-2">
                  {project.methodology.software.map((s, idx) => (
                    <span key={idx} className="px-3 py-1 rounded-md bg-slate-100 border border-slate-200 font-mono text-xs font-semibold text-slate-800">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Results */}
          {activeTab === 'results' && (
            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl text-blue-950 text-sm">
                <div className="font-bold uppercase text-xs font-mono text-blue-800 mb-1">Empirical Synthesis</div>
                {project.empiricalResults.summary}
              </div>

              {project.empiricalResults.metrics && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono mb-3">
                    Key Performance Metrics
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {project.empiricalResults.metrics.map((metric, i) => (
                      <div key={i} className="bg-slate-50 border border-slate-200 p-3 rounded-lg">
                        <div className="text-[10px] text-slate-500 font-mono uppercase">{metric.label}</div>
                        <div className="text-lg font-bold text-slate-900 mt-0.5">{metric.value}</div>
                        {metric.note && (
                          <div className="text-[11px] text-blue-700 mt-0.5 font-mono">{metric.note}</div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {project.empiricalResults.tables && (
                <div className="space-y-6">
                  {project.empiricalResults.tables.map((table, tIdx) => (
                    <div key={tIdx} className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                      <div className="bg-slate-100 px-4 py-2.5 text-xs font-bold text-slate-800 font-mono border-b border-slate-200">
                        {table.title}
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs divide-y divide-slate-200">
                          <thead className="bg-slate-50 text-slate-700 font-mono">
                            <tr>
                              {table.headers.map((h, hIdx) => (
                                <th key={hIdx} className="p-3 font-semibold">
                                  {h}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 bg-white text-slate-800">
                            {table.rows.map((row, rIdx) => (
                              <tr key={rIdx} className="hover:bg-slate-50">
                                {row.map((cell, cIdx) => (
                                  <td key={cIdx} className="p-3 font-mono">
                                    {cell}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      {table.note && (
                        <div className="bg-slate-50 px-4 py-2 text-xs text-slate-500 italic border-t border-slate-200">
                          Note: {table.note}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Tab 4: Diagnostics */}
          {activeTab === 'diagnostics' && (
            <div className="space-y-6">
              {project.diagnosticTests && project.diagnosticTests.length > 0 ? (
                <div className="space-y-4">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono">
                    Diagnostic Testing Results
                  </div>
                  {project.diagnosticTests.map((diag, dIdx) => (
                    <div key={dIdx} className="bg-slate-50 rounded-xl border border-slate-200 p-4 space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-bold text-slate-900 text-sm">{diag.testName}</span>
                        <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-xs font-bold font-mono">
                          {diag.decision}
                        </span>
                      </div>
                      <div className="text-xs text-slate-600">
                        <strong className="font-mono">Null Hypothesis (H0):</strong> {diag.nullHypothesis}
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-white p-2.5 rounded border border-slate-200">
                        <div>Statistic: <span className="font-bold text-slate-800">{diag.statistic}</span></div>
                        <div>p-Value: <span className="font-bold text-slate-800">{diag.pValue}</span></div>
                      </div>
                      <div className="text-xs text-emerald-800 font-medium bg-emerald-50/60 p-2 rounded">
                        Econometric Conclusion: {diag.conclusion}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10 text-slate-500 text-sm">
                  Full diagnostic tests and mathematical derivations available in research report appendices.
                </div>
              )}
            </div>
          )}

          {/* Tab 5: Implications */}
          {activeTab === 'implications' && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono mb-2">
                Scientific Contributions & Emerging Market Policy Implications
              </h4>
              <div className="space-y-3">
                {project.contributionsAndImplications.map((item, idx) => (
                  <div key={idx} className="flex items-start space-x-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <CheckCircle2 className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                    <span className="text-slate-800 text-sm leading-relaxed">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-100 px-6 py-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4 shrink-0">
          <div className="text-xs text-slate-500 font-mono">
            Empirical Research Portfolio • Muhammad Waqas
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition-colors"
            >
              Close Dossier
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
