import React from 'react';
import { GraduationCap, Mail, Globe, ArrowUp, FileText, Award, ShieldCheck } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface FooterProps {
  onOpenCv: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenCv }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#070D18] text-white border-t border-slate-800 text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800/80">
          
          {/* Col 1 & 2: Scholar Bio & Affiliation */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-900 border border-blue-700 flex items-center justify-center text-blue-300 font-serif-academic font-bold text-sm">
                MW
              </div>
              <span className="font-serif-academic text-xl font-bold text-white tracking-wide">
                {PERSONAL_INFO.name}
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Finance Researcher & prospective PhD candidate. Graduate of the Institute of Business Administration (IBA), University of the Punjab. Research focused on Corporate Governance, ESG Moderation, and Financial Econometrics.
            </p>

            <div className="flex flex-wrap gap-2 text-xs text-slate-400">
              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                MBA in Finance (IBA)
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-amber-400">
                ★ 1st in Managerial Econ
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-blue-400">
                ★ 2nd in Master's Thesis
              </span>
            </div>
          </div>

          {/* Col 3: Research Navigation */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
              Research & Studies
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <a href="#thesis" className="hover:text-blue-400 transition-colors">
                  Master's Thesis
                </a>
              </li>
              <li>
                <a href="#research" className="hover:text-blue-400 transition-colors">
                  PSX Econometric Paper
                </a>
              </li>
              <li>
                <a href="#research" className="hover:text-blue-400 transition-colors">
                  Multi-Factor Portfolio Risk
                </a>
              </li>
              <li>
                <a href="#valuation" className="hover:text-blue-400 transition-colors">
                  OGDCL DCF Valuation
                </a>
              </li>
              <li>
                <a href="#interests" className="hover:text-blue-400 transition-colors">
                  Research Taxonomy
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Qualifications */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
              Academic Background
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <a href="#about" className="hover:text-blue-400 transition-colors">
                  Research Profile
                </a>
              </li>
              <li>
                <a href="#education" className="hover:text-blue-400 transition-colors">
                  Education & Coursework
                </a>
              </li>
              <li>
                <a href="#methods" className="hover:text-blue-400 transition-colors">
                  STATA & Econometrics
                </a>
              </li>
              <li>
                <a href="#teaching" className="hover:text-blue-400 transition-colors">
                  Teaching & Mentoring
                </a>
              </li>
              <li>
                <a href="#certifications" className="hover:text-blue-400 transition-colors">
                  Oxford Saïd ESG Credential
                </a>
              </li>
            </ul>
          </div>

          {/* Col 5: Direct Actions */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
              Dossier & Contact
            </h4>
            <div className="space-y-2">
              <button
                onClick={onOpenCv}
                className="w-full py-2 px-3 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>View Academic CV</span>
              </button>

              <a
                href="#contact"
                className="w-full py-2 px-3 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>PhD Inquiry</span>
              </a>
            </div>
            <div className="text-[11px] text-slate-500 font-mono pt-2">
              {PERSONAL_INFO.email}
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} Muhammad Waqas. All research methodologies, empirical datasets, and models are academic property.
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center space-x-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <span>Back to top</span>
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

      </div>
    </footer>
  );
};
