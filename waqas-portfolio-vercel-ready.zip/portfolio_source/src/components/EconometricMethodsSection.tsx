import React, { useState } from 'react';
import { Cpu, Terminal, CheckCircle2, Code2, Database, Layers, BookMarked, FileSpreadsheet, ShieldCheck, Binary } from 'lucide-react';
import { TECHNICAL_SKILLS_DATA } from '../data/portfolioData';

export const EconometricMethodsSection: React.FC = () => {
  const [selectedSnippet, setSelectedSnippet] = useState<'panel' | 'capm' | 'diagnostics' | 'volatility'>('panel');

  const codeSnippets = {
    panel: {
      title: 'Panel Data Model (Fixed vs. Random Effects & Hausman Test)',
      language: 'STATA 15',
      code: `* Set panel structure (Cross-section: company_id, Time: year)
xtset company_id year

* Estimate Fixed Effects (Within) Model with moderating interaction
xtreg roa audit_indep inst_own esg_index c.audit_indep#c.esg_index size lev liq, fe
estimates store fe_model

* Estimate Random Effects GLS Model
xtreg roa audit_indep inst_own esg_index c.audit_indep#c.esg_index size lev liq, re
estimates store re_model

* Execute Hausman Specification Test for Endogeneity Consistency
hausman fe_model re_model`
    },
    capm: {
      title: 'CAPM Regression & Jensen\'s Alpha Estimation',
      language: 'STATA 15',
      code: `* Declare monthly time series structure
tsset mdate, monthly

* Transform price levels to time-additive logarithmic returns (%)
generate LROGDC = 100 * ln(OGDC / L.OGDC)
generate LRKSE  = 100 * ln(KSE100 / L.KSE100)

* Ordinary Least Squares (OLS) CAPM Regression
regress LROGDC LRKSE

* Evaluate Parameter Estimates:
* Beta (Slope): Systematic market risk exposure
* Alpha (Constant): Risk-adjusted abnormal return (Jensen's Alpha)`
    },
    diagnostics: {
      title: 'Heteroskedasticity & Serial Correlation Diagnostic Testing',
      language: 'STATA 15',
      code: `* Post-estimation Breusch-Pagan / Cook-Weisberg test for Heteroskedasticity
* H0: Constant error variance (Homoskedasticity)
estat hettest

* Breusch-Godfrey LM test for higher-order Autocorrelation
* H0: No serial correlation in disturbance terms up to lag 3
estat bgodfrey, lags(1 2 3)

* Multicollinearity diagnostic via Variance Inflation Factor
estat vif`
    },
    volatility: {
      title: 'Descriptive Statistics & Volatility Distribution Matrix',
      language: 'STATA 15',
      code: `* Compute comprehensive summary statistics for price distributions
tabstat KSE100 LUCK PSO OGDC FFC HBL, statistics(mean p50 sd min max) columns(statistics)

* Compute standard deviation of logarithmic returns for cross-sectional volatility ranking
tabstat LRLUCK LRPSO LROGDC LRFFC LRHBL, statistics(sd) columns(statistics)

* Generate time-series price trajectory visualization
tsline OGDC, title("OGDC Monthly Price Trajectory (2024-2026)")`
    }
  };

  return (
    <section id="methods" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-blue-700 mb-2">
            <Cpu className="w-4 h-4" />
            <span>Methodological Capabilities</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Research Methods, Econometrics & Technical Skills
          </h2>
          <div className="w-16 h-1 bg-blue-700 mt-3.5 mb-4"></div>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Proficiencies across quantitative econometrics, diagnostic robustness validation, multi-statement financial modeling, and specialized academic software.
          </p>
        </div>

        {/* 3 Categories Matrix */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-14 text-left">
          
          {/* Econometric Methods */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs">
            <div className="flex items-center space-x-3 pb-4 border-b border-slate-100 mb-4">
              <div className="w-9 h-9 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700">
                <Binary className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif-academic font-bold text-lg text-slate-900">Quantitative Econometrics</h3>
                <div className="text-xs text-slate-500 font-mono">Statistical Methods</div>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              {TECHNICAL_SKILLS_DATA.econometrics.map((skill, idx) => (
                <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                  <div className="font-bold text-slate-900">{skill.name}</div>
                  <div className="text-slate-600 mt-0.5 leading-relaxed">{skill.details}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Financial Modeling & Valuation */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs">
            <div className="flex items-center space-x-3 pb-4 border-b border-slate-100 mb-4">
              <div className="w-9 h-9 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif-academic font-bold text-lg text-slate-900">Financial Modeling</h3>
                <div className="text-xs text-slate-500 font-mono">Valuation & DCF Frameworks</div>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              {TECHNICAL_SKILLS_DATA.valuationAndModeling.map((skill, idx) => (
                <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                  <div className="font-bold text-slate-900">{skill.name}</div>
                  <div className="text-slate-600 mt-0.5 leading-relaxed">{skill.details}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Software & Tools */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs">
            <div className="flex items-center space-x-3 pb-4 border-b border-slate-100 mb-4">
              <div className="w-9 h-9 rounded-lg bg-purple-50 border border-purple-200 flex items-center justify-center text-purple-700">
                <Terminal className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif-academic font-bold text-lg text-slate-900">Software & Digital Tools</h3>
                <div className="text-xs text-slate-500 font-mono">Research Stack</div>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              {TECHNICAL_SKILLS_DATA.softwareAndTools.map((tool, idx) => (
                <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-900">{tool.name}</span>
                    <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px] font-semibold font-mono">
                      {tool.proficiency}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">{tool.category}</div>
                  <div className="text-slate-600 mt-1">{tool.uses}</div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Interactive STATA Command & Econometric Workflow Terminal */}
        <div className="bg-[#0B1120] rounded-2xl border border-slate-800 shadow-xl overflow-hidden text-left">
          
          <div className="bg-[#0F172A] px-6 py-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center space-x-2">
              <Terminal className="w-4 h-4 text-blue-400" />
              <span className="font-mono text-xs font-bold text-slate-200 uppercase tracking-wider">
                STATA 15 & Econometric Routine Scripts
              </span>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {[
                { id: 'panel', label: 'Panel FE/RE & Hausman' },
                { id: 'capm', label: 'CAPM Regression' },
                { id: 'diagnostics', label: 'Diagnostic Checks' },
                { id: 'volatility', label: 'Descriptives & Log-Returns' }
              ].map((btn) => (
                <button
                  key={btn.id}
                  onClick={() => setSelectedSnippet(btn.id as any)}
                  className={`px-3 py-1 text-xs font-mono rounded-md transition-colors cursor-pointer ${
                    selectedSnippet === btn.id
                      ? 'bg-blue-600 text-white font-semibold'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {btn.label}
                </button>
              ))}
            </div>
          </div>

          <div className="p-6">
            <div className="text-xs font-semibold text-blue-400 font-mono mb-2">
              # {codeSnippets[selectedSnippet].title}
            </div>
            <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs sm:text-sm text-emerald-400 overflow-x-auto leading-relaxed">
              <code>{codeSnippets[selectedSnippet].code}</code>
            </pre>
            <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
              <span>Tool: {codeSnippets[selectedSnippet].language}</span>
              <span className="text-slate-500">Reproducible Empirical Code Base</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
