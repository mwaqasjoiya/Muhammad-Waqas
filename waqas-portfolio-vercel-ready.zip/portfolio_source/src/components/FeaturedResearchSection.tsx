import React, { useState } from 'react';
import { BookOpen, FileText, ArrowRight, Table2, Activity, CheckCircle, BarChart2, ShieldAlert, Cpu, ExternalLink } from 'lucide-react';
import { FEATURED_RESEARCH_PROJECTS } from '../data/portfolioData';
import { ResearchProject } from '../types';

interface FeaturedResearchSectionProps {
  onOpenModal: (project: ResearchProject) => void;
}

export const FeaturedResearchSection: React.FC<FeaturedResearchSectionProps> = ({ onOpenModal }) => {
  // We exclude the major thesis from the list since it has its own prominent section above
  const econometricProjects = FEATURED_RESEARCH_PROJECTS.filter((p) => p.id !== 'thesis-master' && p.type === 'Academic Empirical Research');

  return (
    <section id="research" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-blue-700 mb-2">
            <BarChart2 className="w-4 h-4" />
            <span>Empirical Research & Working Papers</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Econometric & Asset Pricing Studies
          </h2>
          <div className="w-16 h-1 bg-blue-700 mt-3.5 mb-4"></div>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Completed empirical research papers applying time-series and panel econometrics in STATA and statistical software.
          </p>
        </div>

        {/* Projects Stack */}
        <div className="space-y-10">
          {econometricProjects.map((project, idx) => (
            <div
              key={project.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-all overflow-hidden text-left"
            >
              {/* Header bar */}
              <div className="bg-slate-900 text-white p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className="px-2.5 py-0.5 rounded bg-blue-900 text-blue-200 text-xs font-semibold font-mono">
                      {project.courseOrContext}
                    </span>
                    <span className="px-2.5 py-0.5 rounded bg-slate-800 text-slate-300 text-xs font-mono">
                      {project.supervisorOrFaculty}
                    </span>
                  </div>
                  <h3 className="font-serif-academic text-xl sm:text-2xl font-bold text-white leading-snug">
                    {project.title}
                  </h3>
                  <div className="text-xs text-blue-300 mt-1 font-mono">{project.date}</div>
                </div>

                <button
                  onClick={() => onOpenModal(project)}
                  className="shrink-0 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer"
                >
                  <span>View Paper Details</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              {/* Main Content Body */}
              <div className="p-6 sm:p-8 space-y-6">
                
                {/* Abstract */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono mb-2">
                    Executive Abstract
                  </h4>
                  <p className="text-slate-700 text-sm sm:text-base leading-relaxed">
                    {project.abstract}
                  </p>
                </div>

                {/* Key Metrics Grid */}
                {project.empiricalResults.metrics && (
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono mb-3">
                      Key Econometric & Empirical Results
                    </h4>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                      {project.empiricalResults.metrics.map((metric, i) => (
                        <div key={i} className="bg-slate-50 border border-slate-200 p-3 rounded-lg">
                          <div className="text-[10px] text-slate-500 font-mono uppercase truncate">{metric.label}</div>
                          <div className="text-base font-bold text-slate-900 mt-0.5">{metric.value}</div>
                          {metric.note && (
                            <div className="text-[10px] text-blue-700 mt-0.5 leading-tight">{metric.note}</div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Tables Preview if available */}
                {project.empiricalResults.tables && project.empiricalResults.tables.length > 0 && (
                  <div className="space-y-4">
                    {project.empiricalResults.tables.slice(0, 1).map((table, tIdx) => (
                      <div key={tIdx} className="overflow-x-auto border border-slate-200 rounded-lg">
                        <div className="bg-slate-100 px-4 py-2 text-xs font-bold text-slate-800 font-mono border-b border-slate-200">
                          {table.title}
                        </div>
                        <table className="w-full text-left text-xs divide-y divide-slate-200">
                          <thead className="bg-slate-50 text-slate-600 font-mono">
                            <tr>
                              {table.headers.map((h, hIdx) => (
                                <th key={hIdx} className="p-2.5 font-semibold">
                                  {h}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
                            {table.rows.map((row, rIdx) => (
                              <tr key={rIdx} className="hover:bg-slate-50">
                                {row.map((cell, cIdx) => (
                                  <td key={cIdx} className="p-2.5 font-mono">
                                    {cell}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {table.note && (
                          <div className="bg-slate-50 px-4 py-1.5 text-[11px] text-slate-500 italic border-t border-slate-200">
                            Note: {table.note}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Diagnostic Tests Preview */}
                {project.diagnosticTests && project.diagnosticTests.length > 0 && (
                  <div className="bg-blue-50/50 border border-blue-200/60 p-4 rounded-xl">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-blue-900 font-mono mb-2 flex items-center space-x-1.5">
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                      <span>Model Diagnostics & Robustness Validations</span>
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                      {project.diagnosticTests.slice(0, 2).map((diag, dIdx) => (
                        <div key={dIdx} className="bg-white p-3 rounded-lg border border-slate-200">
                          <div className="font-semibold text-slate-900">{diag.testName}</div>
                          <div className="text-[11px] text-slate-500 mt-0.5 font-mono">Statistic: {diag.statistic} | p-value: {diag.pValue}</div>
                          <div className="text-[11px] text-emerald-700 font-medium mt-1">Outcome: {diag.decision} — {diag.conclusion}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Bottom Actions */}
                <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-100">
                  <div className="flex flex-wrap gap-1.5">
                    {project.methodology.techniques.slice(0, 4).map((tech, i) => (
                      <span key={i} className="px-2.5 py-1 rounded bg-slate-100 text-slate-700 text-xs font-medium">
                        {tech}
                      </span>
                    ))}
                  </div>

                  <button
                    onClick={() => onOpenModal(project)}
                    className="text-xs font-semibold text-blue-700 hover:text-blue-900 flex items-center space-x-1 cursor-pointer"
                  >
                    <span>Read Full Methodology & Equations</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
