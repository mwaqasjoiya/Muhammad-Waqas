import React from 'react';
import { Award, CheckCircle2, ExternalLink, Calendar, ShieldCheck, Sparkles, GraduationCap } from 'lucide-react';
import { CERTIFICATIONS_DATA } from '../data/portfolioData';

export const CertificationsSection: React.FC = () => {
  return (
    <section id="certifications" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-blue-700 mb-2">
            <Award className="w-4 h-4" />
            <span>Executive & Academic Development</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Professional Certifications & Seminars
          </h2>
          <div className="w-16 h-1 bg-blue-700 mt-3.5 mb-4"></div>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Verified academic credentials in ESG & Sustainability (Oxford Saïd), Corporate Finance (CFI), Logistic Regression (SPSS), and Portfolio Risk.
          </p>
        </div>

        {/* Certifications Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
          {CERTIFICATIONS_DATA.map((cert, idx) => (
            <div
              key={idx}
              className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs hover:shadow-md hover:border-blue-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                    {cert.isUniversityAuthorized ? '🏛️ University Authorized' : '📜 Certified Credential'}
                  </span>
                  <span className="text-xs text-slate-500 font-mono">{cert.date}</span>
                </div>

                <h3 className="font-serif-academic text-lg font-bold text-slate-900 leading-snug">
                  {cert.title}
                </h3>
                <div className="text-xs font-semibold text-blue-800 mt-1 mb-3">
                  {cert.issuer}
                </div>

                <p className="text-slate-600 text-xs leading-relaxed mb-4">
                  {cert.description}
                </p>
              </div>

              <div>
                <div className="flex flex-wrap gap-1 mb-4">
                  {cert.skills.map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>

                {cert.credentialUrl ? (
                  <a
                    href={cert.credentialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-3 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors border border-blue-200"
                  >
                    <span>View Certificate</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                ) : (
                  <div className="py-1.5 px-3 rounded bg-slate-50 text-slate-400 text-[11px] font-mono text-center border border-slate-100">
                    Verified via Coursera / Institute Dossier
                  </div>
                )}
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
