import React, { useState, useEffect } from 'react';
import { BookOpen, FileText, Mail, GraduationCap, Menu, X, ExternalLink, Download } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface NavbarProps {
  onOpenCv: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenCv }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Research Interests', href: '#interests' },
    { name: 'Master\'s Thesis', href: '#thesis' },
    { name: 'Econometric Research', href: '#research' },
    { name: 'Applied Valuation', href: '#valuation' },
    { name: 'Methods & Tools', href: '#methods' },
    { name: 'Education', href: '#education' },
    { name: 'Teaching', href: '#teaching' },
    { name: 'Certifications', href: '#certifications' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#0F172A]/95 backdrop-blur-md shadow-md border-b border-slate-800 text-white py-3'
          : 'bg-[#0F172A] text-white py-4 border-b border-slate-800/80'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo / Scholar Branding */}
          <a
            href="#"
            id="nav-brand-logo"
            className="flex items-center space-x-3 group text-left focus:outline-none"
          >
            <div className="w-10 h-10 rounded-lg bg-blue-700/80 border border-blue-400/30 flex items-center justify-center text-white font-serif font-bold text-xl shadow-sm group-hover:bg-blue-600 transition-colors">
              W
            </div>
            <div>
              <div className="font-serif-academic font-bold text-lg leading-tight tracking-tight text-slate-100 group-hover:text-blue-200 transition-colors">
                {PERSONAL_INFO.name}
              </div>
              <div className="text-[11px] font-sans text-slate-400 uppercase tracking-widest">
                Finance Researcher • PhD Candidate
              </div>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center space-x-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="px-2.5 py-1.5 text-[13px] font-medium text-slate-300 hover:text-white hover:bg-slate-800/60 rounded-md transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Action CTAs */}
          <div className="hidden sm:flex items-center space-x-3">
            <button
              id="nav-btn-cv"
              onClick={onOpenCv}
              className="inline-flex items-center space-x-2 px-3.5 py-2 text-xs font-semibold uppercase tracking-wider rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors shadow-xs"
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>Academic CV</span>
            </button>

            <a
              id="nav-btn-contact"
              href="#contact"
              className="inline-flex items-center space-x-2 px-3.5 py-2 text-xs font-semibold uppercase tracking-wider rounded-md bg-blue-600 hover:bg-blue-500 text-white transition-colors shadow-xs"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>PhD Inquiry</span>
            </a>
          </div>

          {/* Mobile menu toggle button */}
          <div className="flex xl:hidden items-center space-x-2">
            <button
              onClick={onOpenCv}
              className="sm:hidden p-2 text-slate-300 hover:text-white rounded-md bg-slate-800 border border-slate-700"
              title="View CV"
            >
              <FileText className="w-4 h-4 text-blue-400" />
            </button>
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md text-slate-300 hover:text-white hover:bg-slate-800 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#0B1120] border-b border-slate-800 px-4 pt-3 pb-6 space-y-2 text-slate-200 animate-fadeIn">
          <div className="grid grid-cols-1 gap-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-medium text-slate-300 hover:bg-slate-800/80 hover:text-white rounded-md transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>
          <div className="pt-3 border-t border-slate-800 flex flex-col sm:hidden space-y-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenCv();
              }}
              className="w-full py-2.5 px-4 text-xs font-semibold uppercase tracking-wider rounded-md bg-slate-800 text-slate-200 border border-slate-700 flex items-center justify-center space-x-2"
            >
              <FileText className="w-4 h-4 text-blue-400" />
              <span>View Full Academic CV</span>
            </button>
            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full py-2.5 px-4 text-xs font-semibold uppercase tracking-wider rounded-md bg-blue-600 text-white flex items-center justify-center space-x-2"
            >
              <Mail className="w-4 h-4" />
              <span>Contact for PhD Collaboration</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
