import React from 'react';
import { BookOpen, GraduationCap, Award, Compass, Target, Database, TrendingUp, CheckCircle, ArrowUpRight } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-blue-700 mb-2">
            <Compass className="w-4 h-4" />
            <span>Academic & Research Profile</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Research Orientation & Academic Background
          </h2>
          <div className="w-16 h-1 bg-blue-700 mt-3.5 mb-4"></div>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Positioning empirical finance research at the intersection of internal corporate governance, ESG disclosures, and econometric asset pricing in emerging markets.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Main Narrative - 8 cols */}
          <div className="lg:col-span-8 space-y-6 text-slate-700 text-base leading-relaxed">
            
            <div className="bg-slate-50 border-l-4 border-blue-700 p-5 rounded-r-lg shadow-2xs">
              <p className="font-serif-academic text-lg text-slate-900 italic">
                "My academic commitment centers on rigorous quantitative inquiry—testing theoretical finance frameworks against empirical reality in emerging equity markets to generate reproducible econometric insights."
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-slate-900 font-serif-academic flex items-center space-x-2">
                <span>Academic Journey & Specialization</span>
              </h3>
              <p>
                I hold a <strong className="text-slate-900 font-semibold">Master of Business Administration (MBA 1.5) in Finance</strong> from the prestigious <strong className="text-slate-900 font-semibold">Institute of Business Administration (IBA), University of the Punjab</strong>, where I achieved a CGPA of <strong className="text-slate-900 font-semibold">3.35/4.00</strong> along with top academic honors: <strong className="text-blue-800 font-semibold">1st Position in Managerial Economics</strong> and <strong className="text-blue-800 font-semibold">2nd Position in the Master's Final Thesis</strong>. Prior to my MBA, I completed my <strong className="text-slate-900 font-semibold">Bachelor of Business Administration (BBA in Finance)</strong> at the University of Education, Lahore (CGPA 3.13/4.00).
              </p>
              <p>
                My Master's thesis—supervised by <strong className="text-slate-900 font-semibold">Dr. Yasir Ashraf</strong>—investigated <em className="text-slate-800">The Nexus Between Corporate Governance Mechanisms and Corporate Financial Performance: Insights From Pakistan's Non-Financial Sector</em>. The research modeled the impact of audit committee independence and institutional shareholding on Return on Assets (ROA), while uniquely incorporating Sustainability/ESG reporting as a moderating factor in panel econometric specifications in STATA.
              </p>
            </div>

            <div className="space-y-4 pt-2">
              <h3 className="text-xl font-bold text-slate-900 font-serif-academic flex items-center space-x-2">
                <span>Quantitative & Methodological Discipline</span>
              </h3>
              <p>
                My empirical competencies encompass panel data econometrics (Fixed Effects, Random Effects, Two-Way Fixed Effects), instrumental variables (2SLS), quantile regressions, and systematic diagnostic testing (Breusch-Pagan for heteroskedasticity, Breusch-Godfrey LM for autocorrelation, and VIF for multicollinearity). I routinely apply these techniques in <strong className="text-slate-900 font-semibold">STATA 15</strong>, <strong className="text-slate-900 font-semibold">SPSS</strong>, and advanced <strong className="text-slate-900 font-semibold">Microsoft Excel</strong> models.
              </p>
              <p>
                Beyond econometric modeling, I have authored institutional-grade three-statement financial models and Free Cash Flow to Firm (FCFF) discounted cash flow valuations for major listed corporations (including Oil & Gas Development Company Limited, Pakistan Oilfields Limited, FrieslandCampina Engro, and National Foods Limited).
              </p>
            </div>

            <div className="space-y-4 pt-2">
              <h3 className="text-xl font-bold text-slate-900 font-serif-academic flex items-center space-x-2">
                <span>Doctoral Research Ambitions</span>
              </h3>
              <p>
                I am actively preparing for <strong className="text-blue-800 font-semibold">fully funded PhD positions, research assistantships, and doctoral opportunities</strong> in Finance, Accounting, or Applied Economics internationally. My goal is to extend emerging-market empirical research into:
              </p>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <li className="flex items-start space-x-2 text-sm text-slate-700 bg-slate-50 p-2.5 rounded border border-slate-200">
                  <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  <span>Mandatory vs. voluntary ESG disclosures in developing economies</span>
                </li>
                <li className="flex items-start space-x-2 text-sm text-slate-700 bg-slate-50 p-2.5 rounded border border-slate-200">
                  <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  <span>Corporate board dynamics and agency cost mitigation</span>
                </li>
                <li className="flex items-start space-x-2 text-sm text-slate-700 bg-slate-50 p-2.5 rounded border border-slate-200">
                  <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  <span>Asset pricing anomalies during sovereign debt transitions</span>
                </li>
                <li className="flex items-start space-x-2 text-sm text-slate-700 bg-slate-50 p-2.5 rounded border border-slate-200">
                  <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  <span>FinTech transmission channels and capital allocation efficiency</span>
                </li>
              </ul>
            </div>

          </div>

          {/* Sidebar Fact Sheet - 4 cols */}
          <div className="lg:col-span-4 space-y-6">
            
            <div className="bg-[#0F172A] text-white p-6 rounded-xl border border-slate-800 shadow-lg">
              <h3 className="font-serif-academic font-bold text-lg text-white border-b border-slate-800 pb-3 mb-4 flex items-center justify-between">
                <span>Scholar Snapshot</span>
                <GraduationCap className="w-5 h-5 text-blue-400" />
              </h3>

              <div className="space-y-3.5 text-xs">
                <div>
                  <div className="text-slate-400 uppercase font-mono text-[10px]">Graduate Degree</div>
                  <div className="text-sm font-semibold text-slate-100 mt-0.5">MBA in Finance (CGPA: 3.35)</div>
                  <div className="text-slate-400">IBA, University of the Punjab</div>
                </div>

                <div className="pt-2 border-t border-slate-800">
                  <div className="text-slate-400 uppercase font-mono text-[10px]">Undergraduate Degree</div>
                  <div className="text-sm font-semibold text-slate-100 mt-0.5">BBA in Finance (CGPA: 3.13)</div>
                  <div className="text-slate-400">University of Education, Lahore</div>
                </div>

                <div className="pt-2 border-t border-slate-800">
                  <div className="text-slate-400 uppercase font-mono text-[10px]">Key Distinctions</div>
                  <div className="text-slate-200 mt-0.5 font-medium">🥇 1st in Managerial Economics</div>
                  <div className="text-slate-200 mt-0.5 font-medium">🥈 2nd in Master's Final Thesis</div>
                </div>

                <div className="pt-2 border-t border-slate-800">
                  <div className="text-slate-400 uppercase font-mono text-[10px]">Primary Software Tools</div>
                  <div className="text-slate-200 mt-0.5 font-mono">STATA 15 • SPSS • MS Excel • Zotero • Mendeley</div>
                </div>

                <div className="pt-2 border-t border-slate-800">
                  <div className="text-slate-400 uppercase font-mono text-[10px]">Languages</div>
                  <div className="text-slate-200 mt-0.5">Urdu (Native)</div>
                  <div className="text-slate-200">English (CEFR C1 Proficient)</div>
                </div>

                <div className="pt-2 border-t border-slate-800">
                  <div className="text-slate-400 uppercase font-mono text-[10px]">Current Academic Target</div>
                  <div className="text-blue-300 font-semibold mt-0.5">
                    Fully Funded PhD / RA Positions (International)
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-800">
                <a
                  href="#contact"
                  className="w-full py-2 px-3 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors"
                >
                  <span>Inquire for Doctoral Supervision</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Teaching & Community Badge */}
            <div className="bg-slate-50 border border-slate-200 p-5 rounded-xl text-left">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-2 font-mono flex items-center space-x-1.5">
                <Award className="w-4 h-4 text-amber-600" />
                <span>Pedagogical Experience</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Experience instructing graduate peers in econometric routines (STATA, SPSS), lecturing collegiate cohorts in Finance & Economics, and founding Elevate Academy for specialized thesis mentoring.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
