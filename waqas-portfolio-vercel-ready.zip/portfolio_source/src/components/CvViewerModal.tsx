import React from 'react';
import { X, Printer, Download, Mail, Phone, MapPin, Globe, Award, BookOpen, GraduationCap, Briefcase, FileCheck, CheckCircle2 } from 'lucide-react';
import { PERSONAL_INFO, EDUCATION_DATA, MAJOR_THESIS_PROJECT, FEATURED_RESEARCH_PROJECTS, TEACHING_EXPERIENCE_DATA, PROFESSIONAL_EXPERIENCE_DATA, CERTIFICATIONS_DATA } from '../data/portfolioData';

interface CvViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CvViewerModal: React.FC<CvViewerModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadText = () => {
    const cvText = `
================================================================================
CURRICULUM VITAE
MUHAMMAD WAQAS
Finance Researcher | Prospective PhD Candidate
Email: ${PERSONAL_INFO.email}
Phone: ${PERSONAL_INFO.phone}
Address: ${PERSONAL_INFO.address}
LinkedIn: ${PERSONAL_INFO.linkedin}
================================================================================

ACADEMIC RESEARCH PROFILE
--------------------------------------------------------------------------------
Finance researcher specializing in Corporate Governance, Sustainability (ESG) Reporting,
Empirical Asset Pricing, and Panel Data Econometrics. Graduate of Institute of Business
Administration (IBA), University of the Punjab. Seeking fully funded PhD positions,
Research Assistantships, and academic appointments internationally.

EDUCATION
--------------------------------------------------------------------------------
1. Master of Business Administration (MBA 1.5) - Finance
   Institute of Business Administration (IBA), University of the Punjab, Lahore
   Dates: Oct 2024 - 2026 | CGPA: 3.35 / 4.00
   Distinctions:
   - 1st Position in Managerial Economics
   - 2nd Position in Master's Final Research Thesis
   Thesis Title: The Nexus Between Corporate Governance Mechanisms and Corporate Financial Performance: Insights From Pakistan's Non-Financial Sector
   Supervisor: Dr. Yasir Ashraf

2. Bachelor of Business Administration (BBA) - Finance
   University of Education, Lahore (Multan Campus)
   Dates: Oct 2020 - Aug 2024 | CGPA: 3.13 / 4.00

PRIMARY RESEARCH & WORKING PAPERS
--------------------------------------------------------------------------------
1. Master's Thesis: The Nexus Between Corporate Governance Mechanisms and Corporate Financial Performance: Insights From Pakistan's Non-Financial Sector (Supervisor: Dr. Yasir Ashraf)
   - Evaluated audit committee independence, institutional ownership, and ESG moderation on ROA using Panel Fixed/Random Effects in STATA 15.

2. Empirical Asset Pricing & CAPM Estimation: PSX Equity Analysis (Supervisor: Dr. Humaira Asad, IBA)
   - Analyzed 120 monthly observations across PSX equities vs KSE-100 index in STATA 15. Estimated Beta, Jensen's Alpha, and diagnostic tests (Breusch-Pagan, Breusch-Godfrey LM).

3. Multi-Factor Risk-Return Analysis & Portfolio Management (Supervisor: Dr. Naseem Bukhari, IBA)
   - Conducted multi-asset equity analysis (JPM, NVDA, KO vs S&P 500) over 751 observations using Fama-French 4-factor regression frameworks.

4. Upstream Oil & Gas 3-Statement Modeling & FCFF DCF Valuation (OGDCL vs POL)
   - Authored institutional-grade three-statement model and DCF equity valuation (Target PKR 207 vs market PKR 135, +53% upside).

TEACHING & INSTRUCTIONAL EXPERIENCE
--------------------------------------------------------------------------------
- Student Instructor - Research Methods & Statistical Software (IBA Punjab University) [Nov 2024 - Present]
- Founder & Academic Tutor - Elevate Academy [Aug 2026 - Present]
- Lecturer in Accounting, Finance & Economics - Islamic College of Science & Arts [Dec 2025 - May 2026]
- Volunteer Instructor - Free Summer Learning Program [Jun 2020 - Aug 2024]

PROFESSIONAL EXPERIENCE
--------------------------------------------------------------------------------
- Assistant Finance Manager - Mazcorp Engineering [May 2026 - Aug 2026]
- Sharebuyback Trainee Analyst - 2iQ Human Resource Solutions [Jul 2025 - Nov 2025]
- Audit & Tax Intern - Federal Board of Revenue (FBR) [Jun 2023 - Aug 2023]

EXECUTIVE CERTIFICATIONS
--------------------------------------------------------------------------------
- Foundations of Sustainability and ESG (Saïd Business School, University of Oxford / Coursera)
- Corporate Finance Fundamentals (Corporate Finance Institute - CFI / Coursera)
- SPSS: Apply & Interpret Logistic Regression Models (EDUCBA / Coursera)
- Investment Risk Management Project Certificate (Coursera Project Network)
- Leadvolution Virtual Leadership Summit 2025 (Certificate of Participation)

SOFTWARE & METHODOLOGICAL STACK
--------------------------------------------------------------------------------
- Econometrics & Statistics: STATA 15, SPSS, Panel Data Regressions (FE/RE), Hausman Test, Diagnostic Testing
- Financial Modeling: Advanced MS Excel (3-Statement Financial Modeling, FCFF DCF, WACC, Scenario Analysis)
- Academic Tools: Zotero, Mendeley, EndNote, MS Word, LaTeX
- Languages: Urdu (Native), English (CEFR C1 Academic Proficient)
================================================================================
`;

    const blob = new Blob([cvText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Muhammad_Waqas_Academic_CV_2026.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-2 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-5xl bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden flex flex-col max-h-[92vh] text-left">
        
        {/* Action Header Bar (Hidden during print) */}
        <div className="bg-[#0F172A] text-white p-4 sm:p-5 flex items-center justify-between gap-4 border-b border-slate-800 shrink-0 print:hidden">
          <div className="flex items-center space-x-2">
            <GraduationCap className="w-5 h-5 text-blue-400" />
            <span className="font-serif-academic font-bold text-lg sm:text-xl text-white">
              Official Academic Curriculum Vitae
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>

            <button
              onClick={handleDownloadText}
              className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer border border-slate-700"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Text CV</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-2 cursor-pointer"
              aria-label="Close CV Modal"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* CV Document Body (Printable canvas) */}
        <div className="p-6 sm:p-12 overflow-y-auto bg-white font-sans text-slate-800 print:p-0 print:overflow-visible">
          
          {/* Header */}
          <div className="text-center pb-6 border-b-2 border-slate-900">
            <h1 className="font-serif-academic text-3xl sm:text-4xl font-bold tracking-tight text-slate-950 uppercase">
              {PERSONAL_INFO.name}
            </h1>
            <p className="text-sm font-semibold text-slate-700 mt-1 uppercase tracking-wider font-mono">
              Finance Researcher | Prospective PhD Candidate
            </p>
            
            <div className="flex flex-wrap justify-center items-center gap-x-5 gap-y-1.5 text-xs text-slate-600 mt-3 font-mono">
              <span className="flex items-center space-x-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{PERSONAL_INFO.address}</span>
              </span>
              <span>•</span>
              <span className="flex items-center space-x-1">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                <span>{PERSONAL_INFO.email}</span>
              </span>
              <span>•</span>
              <span className="flex items-center space-x-1">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                <span>{PERSONAL_INFO.phone}</span>
              </span>
              <span>•</span>
              <span className="flex items-center space-x-1 text-blue-700">
                <Globe className="w-3.5 h-3.5" />
                <span>linkedin.com/in/muhammad-waqas</span>
              </span>
            </div>
          </div>

          {/* Academic Statement */}
          <div className="py-5 border-b border-slate-200">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-950 font-mono mb-2">
              ACADEMIC RESEARCH PROFILE
            </h2>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              Research-oriented Finance graduate with deep specialization in corporate governance mechanisms, board oversight, ESG/sustainability reporting, and empirical econometric modeling. Master's thesis awarded 2nd Position at IBA, University of the Punjab. Experienced in longitudinal panel data econometrics in STATA 15, asset pricing anomalies, and institutional equity valuation. Actively seeking fully funded PhD positions and research assistantships in Finance, Accounting, and Applied Economics.
            </p>
          </div>

          {/* Education */}
          <div className="py-5 border-b border-slate-200 space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-950 font-mono">
              EDUCATION
            </h2>
            
            {EDUCATION_DATA.map((edu, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between items-baseline text-xs sm:text-sm">
                  <div className="font-bold text-slate-950">
                    {edu.degree} — {edu.institution} {edu.campus && `(${edu.campus})`}
                  </div>
                  <div className="font-mono text-slate-600 text-xs">{edu.dates}</div>
                </div>
                <div className="flex justify-between text-xs text-slate-600">
                  <div>Field of Specialization: <strong className="text-slate-800">{edu.field}</strong></div>
                  <div className="font-mono font-bold text-slate-900">CGPA: {edu.cgpa} / {edu.maxGpa}</div>
                </div>
                {edu.thesisTitle && (
                  <div className="text-xs text-slate-700 pt-0.5">
                    <strong>Master's Thesis:</strong> <em>{edu.thesisTitle}</em> (Supervisor: {edu.supervisor})
                  </div>
                )}
                {edu.distinctions && (
                  <div className="flex flex-wrap gap-2 text-xs text-blue-900 pt-0.5">
                    {edu.distinctions.map((d, dIdx) => (
                      <span key={dIdx} className="font-semibold bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                        ★ {d}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Academic Research & Thesis */}
          <div className="py-5 border-b border-slate-200 space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-950 font-mono">
              RESEARCH PAPERS & WORKING THESES
            </h2>

            <div className="space-y-3 text-xs sm:text-sm">
              <div className="space-y-0.5">
                <div className="font-bold text-slate-950">
                  1. The Nexus Between Corporate Governance Mechanisms and Corporate Financial Performance: Insights From Pakistan's Non-Financial Sector (Awarded 2nd Position)
                </div>
                <div className="text-xs text-slate-600 font-mono">
                  Master's Thesis • Supervisor: Dr. Yasir Ashraf • STATA 15 Panel Regressions (Fixed & Random Effects)
                </div>
                <div className="text-xs text-slate-700">
                  Model: ROA_it = β_0 + β_1(AuditIndep) + β_2(InstOwn) + β_3(ESG) + β_4(Gov × ESG) + γ Controls + μ_i + ε_it. Evaluated board oversight and ESG moderation in PSX listed companies.
                </div>
              </div>

              <div className="space-y-0.5">
                <div className="font-bold text-slate-950">
                  2. Empirical Asset Pricing & CAPM Estimation: PSX Equity Analysis
                </div>
                <div className="text-xs text-slate-600 font-mono">
                  Econometric Paper • Supervisor: Dr. Humaira Asad • 120 Monthly Observations (2024–2026)
                </div>
                <div className="text-xs text-slate-700">
                  Analyzed OGDC, LUCK, PSO, FFC, and HBL vs KSE-100 index in STATA. Estimated Beta (1.127, t=6.53), Alpha (-0.0168), Breusch-Pagan homoskedasticity (p=0.2467), Breusch-Godfrey autocorrelation.
                </div>
              </div>

              <div className="space-y-0.5">
                <div className="font-bold text-slate-950">
                  3. Multi-Factor Risk-Return Analysis & Portfolio Management
                </div>
                <div className="text-xs text-slate-600 font-mono">
                  Portfolio Analysis • Supervisor: Dr. Naseem Bukhari • 751 Daily Observations (2023–2026)
                </div>
                <div className="text-xs text-slate-700">
                  Multi-asset equity evaluation (JPM, NVDA, KO vs S&P 500) implementing Fama-French 4-factor regressions and Jensen's Alpha estimation (α = 0.0150, t = 12.15).
                </div>
              </div>

              <div className="space-y-0.5">
                <div className="font-bold text-slate-950">
                  4. Upstream Oil & Gas 3-Statement Model & FCFF DCF Valuation (OGDCL vs POL)
                </div>
                <div className="text-xs text-slate-600 font-mono">
                  Applied Equity Valuation • WACC 26.48% • DCF Target Price PKR 207 vs Market PKR 135
                </div>
                <div className="text-xs text-slate-700">
                  Constructed dynamic 3-statement forecast, terminal growth sensitivity engine, and Damodaran ERP derivation.
                </div>
              </div>
            </div>
          </div>

          {/* Teaching Experience */}
          <div className="py-5 border-b border-slate-200 space-y-3">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-950 font-mono">
              TEACHING & INSTRUCTIONAL MENTORING
            </h2>
            <div className="space-y-2.5 text-xs sm:text-sm">
              {TEACHING_EXPERIENCE_DATA.map((t, idx) => (
                <div key={idx}>
                  <div className="flex justify-between items-baseline font-semibold text-slate-900 text-xs sm:text-sm">
                    <div>{t.role} — <em>{t.institution}</em></div>
                    <div className="font-mono text-slate-500 text-xs">{t.dates}</div>
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {t.highlights.join(' • ')}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Professional Experience */}
          <div className="py-5 border-b border-slate-200 space-y-3">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-950 font-mono">
              PROFESSIONAL EXPERIENCE
            </h2>
            <div className="space-y-2.5 text-xs sm:text-sm">
              {PROFESSIONAL_EXPERIENCE_DATA.map((p, idx) => (
                <div key={idx}>
                  <div className="flex justify-between items-baseline font-semibold text-slate-900 text-xs sm:text-sm">
                    <div>{p.role} — {p.organization} ({p.location})</div>
                    <div className="font-mono text-slate-500 text-xs">{p.dates}</div>
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {p.highlights.join(' • ')}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Executive Certifications */}
          <div className="py-5 border-b border-slate-200 space-y-2">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-950 font-mono">
              CERTIFICATIONS & PROFESSIONAL DEVELOPMENT
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {CERTIFICATIONS_DATA.map((c, idx) => (
                <div key={idx} className="bg-slate-50 p-2 rounded border border-slate-200">
                  <div className="font-bold text-slate-900">{c.title}</div>
                  <div className="text-slate-600">{c.issuer} ({c.date})</div>
                </div>
              ))}
            </div>
          </div>

          {/* Software Stack & Languages */}
          <div className="pt-5 space-y-2">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-950 font-mono">
              TECHNICAL & RESEARCH SKILLS
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <strong>Statistical Software & Econometrics:</strong> STATA 15, SPSS, Panel Data Regressions, Time Series, CAPM, Diagnostic Tests.
              </div>
              <div>
                <strong>Financial Modeling:</strong> MS Excel (3-Statement Financial Modeling, FCFF DCF Valuations, WACC, Scenario Analysis).
              </div>
              <div>
                <strong>Academic Tools:</strong> Zotero, Mendeley, EndNote, MS Office, LaTeX.
              </div>
              <div>
                <strong>Languages:</strong> Urdu (Native), English (CEFR C1 Academic Proficient).
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
