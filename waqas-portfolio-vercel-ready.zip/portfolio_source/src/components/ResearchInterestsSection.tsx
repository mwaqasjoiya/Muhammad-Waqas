import React, { useState } from 'react';
import { Layers, Sparkles, CheckCircle2, Bookmark, ArrowRight, ShieldCheck, Scale, LineChart, Globe2, Cpu, Activity, Coins } from 'lucide-react';
import { RESEARCH_INTERESTS_DATA } from '../data/portfolioData';

export const ResearchInterestsSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<number>(0);

  const getIconForInterest = (name: string) => {
    if (name.includes('Governance')) return <ShieldCheck className="w-5 h-5 text-blue-600" />;
    if (name.includes('Sustainability') || name.includes('ESG')) return <Globe2 className="w-5 h-5 text-emerald-600" />;
    if (name.includes('Econometrics') || name.includes('Panel Data')) return <LineChart className="w-5 h-5 text-indigo-600" />;
    if (name.includes('Asset Pricing')) return <Activity className="w-5 h-5 text-amber-600" />;
    if (name.includes('Valuation')) return <Scale className="w-5 h-5 text-cyan-600" />;
    if (name.includes('FinTech')) return <Cpu className="w-5 h-5 text-purple-600" />;
    if (name.includes('Behavioral')) return <Sparkles className="w-5 h-5 text-rose-600" />;
    return <Coins className="w-5 h-5 text-blue-600" />;
  };

  return (
    <section id="interests" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-blue-700 mb-2">
            <Layers className="w-4 h-4" />
            <span>Research Taxonomy</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Research Interests & Scientific Domains
          </h2>
          <div className="w-16 h-1 bg-blue-700 mt-3.5 mb-4"></div>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Organized into core demonstrated empirical domains and frontier emerging research interests that define my ongoing doctoral trajectory.
          </p>
        </div>

        {/* Category Selector Tabs */}
        <div className="flex flex-wrap gap-2.5 mb-10">
          {RESEARCH_INTERESTS_DATA.map((cat, idx) => (
            <button
              key={cat.category}
              onClick={() => setActiveCategory(idx)}
              className={`px-5 py-2.5 rounded-lg text-sm font-semibold transition-all flex items-center space-x-2 cursor-pointer ${
                activeCategory === idx
                  ? 'bg-[#0F172A] text-white shadow-md'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <span>{cat.category}</span>
              <span
                className={`text-xs px-2 py-0.5 rounded-full font-mono ${
                  activeCategory === idx ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {cat.interests.length}
              </span>
            </button>
          ))}
        </div>

        {/* Active Category Intro */}
        <div className="mb-8 p-4 rounded-lg bg-blue-50/60 border border-blue-200/60 text-sm text-blue-900 flex items-start space-x-3 text-left">
          <Bookmark className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" />
          <div>
            <span className="font-semibold text-blue-950">{RESEARCH_INTERESTS_DATA[activeCategory].category}: </span>
            {RESEARCH_INTERESTS_DATA[activeCategory].description}
          </div>
        </div>

        {/* Interests Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
          {RESEARCH_INTERESTS_DATA[activeCategory].interests.map((interest, i) => (
            <div
              key={interest.name}
              className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs hover:shadow-md hover:border-blue-300 transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-center mb-4 group-hover:bg-blue-50 group-hover:border-blue-200 transition-colors">
                  {getIconForInterest(interest.name)}
                </div>

                <h3 className="font-serif-academic text-lg font-bold text-slate-900 group-hover:text-blue-900 transition-colors">
                  {interest.name}
                </h3>

                <p className="text-slate-600 text-xs sm:text-sm mt-2.5 leading-relaxed">
                  {interest.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2 font-mono">
                  Key Constructs & Themes
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {interest.keyThemes.map((theme) => (
                    <span
                      key={theme}
                      className="px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-[11px] font-medium text-slate-700"
                    >
                      {theme}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
