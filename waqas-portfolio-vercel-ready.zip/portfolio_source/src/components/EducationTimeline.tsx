import React from 'react';
import { GraduationCap, Award, Calendar, MapPin, BookOpen, CheckCircle2, UserCheck } from 'lucide-react';
import { EDUCATION_DATA } from '../data/portfolioData';

export const EducationTimeline: React.FC = () => {
  return (
    <section id="education" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-blue-700 mb-2">
            <GraduationCap className="w-4 h-4" />
            <span>Academic Qualifications</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Education & Academic Timeline
          </h2>
          <div className="w-16 h-1 bg-blue-700 mt-3.5 mb-4"></div>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            University degrees, academic distinctions, research supervisors, and foundational finance coursework.
          </p>
        </div>

        {/* Timeline container */}
        <div className="relative border-l-2 border-slate-200 ml-4 sm:ml-8 space-y-12 text-left">
          {EDUCATION_DATA.map((edu, idx) => (
            <div key={idx} className="relative pl-6 sm:pl-10">
              
              {/* Timeline marker */}
              <div className="absolute -left-3 top-1.5 w-6 h-6 rounded-full bg-blue-700 border-4 border-white shadow-sm flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-white"></div>
              </div>

              {/* Card */}
              <div className="bg-slate-50 rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-2xs hover:shadow-md transition-shadow">
                
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                  <div>
                    <span className="px-2.5 py-0.5 rounded text-[11px] font-bold font-mono bg-blue-100 text-blue-800 uppercase tracking-wider">
                      {edu.field} Specialization
                    </span>
                    <h3 className="font-serif-academic text-2xl font-bold text-slate-900 mt-1">
                      {edu.degree}
                    </h3>
                    <div className="text-sm font-semibold text-slate-700 mt-0.5">
                      {edu.institution} {edu.campus && <span className="font-normal text-slate-500">• {edu.campus}</span>}
                    </div>
                  </div>

                  <div className="text-right md:text-right space-y-1">
                    <div className="inline-flex items-center space-x-1.5 text-xs text-slate-500 font-mono">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>{edu.dates}</span>
                    </div>
                    <div className="text-sm font-bold text-slate-900 font-mono">
                      Cumulative GPA: <span className="text-blue-700">{edu.cgpa}</span> / {edu.maxGpa}
                    </div>
                  </div>
                </div>

                {/* Body Details */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6">
                  
                  {/* Left sub-column: Distinctions & Supervisor */}
                  <div className="lg:col-span-7 space-y-4">
                    
                    {edu.thesisTitle && (
                      <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1.5">
                        <div className="text-[10px] uppercase font-mono text-slate-500 font-bold flex items-center space-x-1">
                          <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                          <span>Master's Research Thesis</span>
                        </div>
                        <div className="font-serif-academic text-sm font-bold text-slate-900">
                          {edu.thesisTitle}
                        </div>
                        {edu.supervisor && (
                          <div className="text-xs text-slate-600 flex items-center space-x-1 pt-1">
                            <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                            <span>Supervisor: <strong>{edu.supervisor}</strong></span>
                          </div>
                        )}
                      </div>
                    )}

                    {edu.distinctions && edu.distinctions.length > 0 && (
                      <div className="space-y-2">
                        <div className="text-xs font-bold uppercase tracking-wider text-slate-600 font-mono flex items-center space-x-1.5">
                          <Award className="w-4 h-4 text-amber-500" />
                          <span>Academic Distinctions & Honors</span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {edu.distinctions.map((dist, dIdx) => (
                            <div
                              key={dIdx}
                              className="bg-amber-50/70 border border-amber-200/80 p-2.5 rounded-lg text-xs font-semibold text-amber-950 flex items-center space-x-2"
                            >
                              <Award className="w-4 h-4 text-amber-600 shrink-0" />
                              <span>{dist}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                  </div>

                  {/* Right sub-column: Advanced Coursework */}
                  <div className="lg:col-span-5 space-y-2">
                    <div className="text-xs font-bold uppercase tracking-wider text-slate-600 font-mono">
                      Core Academic Modules
                    </div>
                    {edu.keyCourses && (
                      <div className="flex flex-wrap gap-1.5">
                        {edu.keyCourses.map((c, cIdx) => (
                          <span
                            key={cIdx}
                            className="px-2.5 py-1 rounded bg-white border border-slate-200 text-xs font-medium text-slate-700"
                          >
                            {c}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                </div>

              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
