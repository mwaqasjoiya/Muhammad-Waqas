import React, { useState } from 'react';
import { Scale, TrendingUp, Sliders, DollarSign, ArrowRight, ShieldCheck, ChevronRight, CheckCircle2, AlertTriangle, Layers } from 'lucide-react';
import { FEATURED_RESEARCH_PROJECTS } from '../data/portfolioData';
import { ResearchProject } from '../types';

interface AppliedFinanceSectionProps {
  onOpenModal: (project: ResearchProject) => void;
}

export const AppliedFinanceSection: React.FC<AppliedFinanceSectionProps> = ({ onOpenModal }) => {
  const valuationProjects = FEATURED_RESEARCH_PROJECTS.filter((p) => p.type === 'Applied Financial Valuation');

  // Interactive DCF Simulator state for OGDCL
  const [wacc, setWacc] = useState<number>(26.48); // %
  const [terminalGrowth, setTerminalGrowth] = useState<number>(4.0); // %

  // Calculation for OGDCL DCF
  // Historical / Explicit Forecasts in PKR mn:
  // FY25 FCFF = 144,834
  // FY26 FCFF = 148,889
  // FY27 FCFF = 152,987
  // Net cash = +259,001
  // Shares = 4,300.93 mn
  // Market price = 135
  const waccDecimal = Math.max(wacc / 100, 0.08);
  const gDecimal = Math.min(terminalGrowth / 100, waccDecimal - 0.01);

  const pvFcff25 = 144834 / Math.pow(1 + waccDecimal, 1);
  const pvFcff26 = 148889 / Math.pow(1 + waccDecimal, 2);
  const pvFcff27 = 152987 / Math.pow(1 + waccDecimal, 3);
  const sumPvFcff = pvFcff25 + pvFcff26 + pvFcff27;

  const terminalValue = (152987 * (1 + gDecimal)) / (waccDecimal - gDecimal);
  const pvTerminalValue = terminalValue / Math.pow(1 + waccDecimal, 3);

  const calculatedEv = Math.round(sumPvFcff + pvTerminalValue);
  const netCash = 259001; // Negative net debt = net cash
  const calculatedEquityValue = Math.round(calculatedEv + netCash);
  const calculatedSharePrice = Math.round(calculatedEquityValue / 4300.93);
  const marketPrice = 135;
  const impliedUpside = Math.round(((calculatedSharePrice - marketPrice) / marketPrice) * 100);

  return (
    <section id="valuation" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12 text-left">
          <div className="inline-flex items-center space-x-2 text-xs font-semibold uppercase tracking-widest text-emerald-700 mb-2">
            <Scale className="w-4 h-4" />
            <span>Applied Corporate Finance & Modeling</span>
          </div>
          <h2 className="font-serif-academic text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Applied Equity Research & DCF Valuations
          </h2>
          <div className="w-16 h-1 bg-emerald-700 mt-3.5 mb-4"></div>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Rigorous three-statement financial modeling, Free Cash Flow to Firm (FCFF) discounted cash flow valuations, WACC derivation, and scenario analysis for listed corporations.
          </p>
        </div>

        {/* Interactive DCF Model Simulator Card */}
        <div className="bg-[#0A1120] text-white rounded-2xl border border-slate-800 p-6 sm:p-8 lg:p-10 mb-14 shadow-xl text-left">
          
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-800">
            <div>
              <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded bg-emerald-950 border border-emerald-700/60 text-emerald-300 text-xs font-mono font-semibold mb-2">
                <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                <span>INTERACTIVE FINANCIAL MODEL SIMULATOR</span>
              </div>
              <h3 className="font-serif-academic text-2xl sm:text-3xl font-bold text-white">
                OGDCL DCF Valuation Sensitivity Engine
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Adjust discount rate (WACC) and long-run terminal growth (g) to observe live recalculation of intrinsic share price and equity upside.
              </p>
            </div>

            <div className="flex items-center space-x-4 bg-slate-900/90 p-3.5 rounded-xl border border-slate-800">
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-mono">Market Price</div>
                <div className="text-xl font-bold text-slate-200">PKR {marketPrice}</div>
              </div>
              <div className="h-8 w-px bg-slate-800"></div>
              <div>
                <div className="text-[10px] text-emerald-400 uppercase font-mono">Simulated DCF Target</div>
                <div className="text-2xl font-bold text-emerald-400">PKR {calculatedSharePrice}</div>
              </div>
              <div className="h-8 w-px bg-slate-800"></div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-mono">Implied Upside</div>
                <div className={`text-xl font-bold ${impliedUpside >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {impliedUpside > 0 ? `+${impliedUpside}%` : `${impliedUpside}%`}
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Sliders & Real-Time Output Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-8">
            
            {/* Sliders Column */}
            <div className="lg:col-span-5 space-y-6 bg-slate-900/60 p-6 rounded-xl border border-slate-800">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-semibold text-slate-300 uppercase font-mono">
                    WACC / Cost of Equity (Ke)
                  </label>
                  <span className="text-sm font-bold text-blue-400 font-mono">{wacc.toFixed(2)}%</span>
                </div>
                <input
                  type="range"
                  min="14"
                  max="28"
                  step="0.5"
                  value={wacc}
                  onChange={(e) => setWacc(parseFloat(e.target.value))}
                  className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                  <span>14% (Monetary Easing)</span>
                  <span>26.48% (Base Report)</span>
                  <span>28%</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-semibold text-slate-300 uppercase font-mono">
                    Terminal Growth Rate (g)
                  </label>
                  <span className="text-sm font-bold text-emerald-400 font-mono">{terminalGrowth.toFixed(1)}%</span>
                </div>
                <input
                  type="range"
                  min="2.0"
                  max="6.0"
                  step="0.5"
                  value={terminalGrowth}
                  onChange={(e) => setTerminalGrowth(parseFloat(e.target.value))}
                  className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                  <span>2.0% (Conservative)</span>
                  <span>4.0% (Base Model)</span>
                  <span>6.0%</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-400">
                <div className="font-semibold text-slate-300 mb-1">Base Model Parameter Notes:</div>
                <div>• Risk-free Rate (10-yr PIB): <span className="font-mono text-slate-200">11.56%</span></div>
                <div>• Equity Risk Premium (Damodaran): <span className="font-mono text-slate-200">13.94%</span></div>
                <div>• OGDC Equity Beta: <span className="font-mono text-slate-200">1.07</span></div>
                <div>• Zero interest-bearing debt → <span className="font-mono text-slate-200">WACC = Cost of Equity</span></div>
              </div>
            </div>

            {/* Recalculated Valuation Breakdown */}
            <div className="lg:col-span-7 space-y-4">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
                Valuation Step-by-Step Waterfall
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">PV of Explicit FCFF (3-Yr)</div>
                  <div className="text-base font-bold text-slate-200 mt-1 font-mono">PKR {Math.round(sumPvFcff).toLocaleString()} mn</div>
                </div>

                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">PV of Terminal Value</div>
                  <div className="text-base font-bold text-slate-200 mt-1 font-mono">PKR {Math.round(pvTerminalValue).toLocaleString()} mn</div>
                </div>

                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Enterprise Value (EV)</div>
                  <div className="text-base font-bold text-blue-400 mt-1 font-mono">PKR {calculatedEv.toLocaleString()} mn</div>
                </div>

                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Net Cash Added</div>
                  <div className="text-base font-bold text-emerald-400 mt-1 font-mono">+PKR 259,001 mn</div>
                </div>

                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Total Equity Value</div>
                  <div className="text-base font-bold text-emerald-300 mt-1 font-mono">PKR {calculatedEquityValue.toLocaleString()} mn</div>
                </div>

                <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Total Shares</div>
                  <div className="text-base font-bold text-slate-200 mt-1 font-mono">4,300.93 mn</div>
                </div>
              </div>

              <div className="p-4 bg-emerald-950/40 border border-emerald-800/60 rounded-xl flex items-center justify-between">
                <div>
                  <div className="text-xs font-mono uppercase text-emerald-400 font-semibold">
                    Simulated Intrinsic Share Price
                  </div>
                  <div className="text-2xl sm:text-3xl font-bold text-white font-serif-academic mt-0.5">
                    PKR {calculatedSharePrice} per share
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-3 py-1 rounded bg-emerald-900 text-emerald-200 text-xs font-bold font-mono">
                    {impliedUpside >= 0 ? `+${impliedUpside}% Upside (BUY)` : `${impliedUpside}% (HOLD/SELL)`}
                  </span>
                </div>
              </div>

            </div>

          </div>

        </div>

        {/* Valuation Reports Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
          {valuationProjects.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-xl border border-slate-200 shadow-2xs hover:shadow-lg hover:border-slate-300 transition-all flex flex-col justify-between overflow-hidden group"
            >
              <div>
                {/* Header tag */}
                <div className="bg-slate-50 border-b border-slate-100 p-4 flex items-center justify-between">
                  <span className="text-xs font-mono font-semibold text-slate-700">{project.courseOrContext}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-blue-100 text-blue-800">
                    {project.date}
                  </span>
                </div>

                <div className="p-6 space-y-4">
                  <h3 className="font-serif-academic text-xl font-bold text-slate-900 group-hover:text-blue-900 transition-colors leading-snug">
                    {project.title}
                  </h3>

                  <p className="text-slate-600 text-xs sm:text-sm leading-relaxed line-clamp-3">
                    {project.abstract}
                  </p>

                  {/* Highlights */}
                  {project.empiricalResults.metrics && (
                    <div className="grid grid-cols-2 gap-2 pt-2">
                      {project.empiricalResults.metrics.slice(0, 4).map((m, idx) => (
                        <div key={idx} className="bg-slate-50 p-2 rounded border border-slate-100">
                          <div className="text-[10px] text-slate-500 font-mono truncate">{m.label}</div>
                          <div className="text-xs font-bold text-slate-900 mt-0.5">{m.value}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="p-6 pt-0">
                <button
                  onClick={() => onOpenModal(project)}
                  className="w-full py-2.5 px-4 rounded-lg bg-slate-900 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center space-x-2 transition-colors cursor-pointer"
                >
                  <span>View Valuation Model & Scenarios</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
