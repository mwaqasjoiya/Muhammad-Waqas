import {
  ResearchProject,
  EducationItem,
  TeachingExperienceItem,
  ProfessionalExperienceItem,
  CertificationItem,
  ResearchInterestCategory
} from '../types';

export const PERSONAL_INFO = {
  name: 'Muhammad Waqas',
  title: 'Finance Researcher | Prospective PhD Candidate',
  subtitle: 'Corporate Governance • Financial Econometrics • Panel Data Analysis • Empirical Asset Pricing & Valuation',
  email: 'finance.mwaqasabid@gmail.com',
  phone: '(+92) 03475024641',
  location: 'Lahore, Pakistan',
  address: 'Lahore, Pakistan',
  nationality: 'Pakistani',
  linkedin: 'https://www.linkedin.com/in/muhammad-waqas',
  languages: [
    { language: 'Urdu', level: 'Native / Mother tongue', cefr: 'C2 Native' },
    {
      language: 'English',
      level: 'Professional Academic Proficiency',
      cefr: 'C1 Proficient (Listening C1, Reading C1, Writing C1, Spoken Interaction C1, Spoken Production B2)'
    }
  ],
  bio: `Research-oriented finance professional with applied expertise in corporate governance, financial econometrics, and empirical valuation. My Master's thesis applies fixed-effects and random-effects panel regression in STATA to examine how board-level governance mechanisms, institutional ownership, and sustainability/ESG reporting shape corporate financial performance (ROA) in Pakistan's non-financial listed sector. This is complemented by independent econometric and valuation work, including CAPM regressions, Fama-French multi-factor risk analysis, and comprehensive FCFF DCF-based equity research on PSX-listed firms. I am actively seeking fully funded doctoral opportunities in Finance, Accounting, or Economics to extend this empirical research agenda into underexplored emerging-market settings.`
};

export const RESEARCH_INTERESTS_DATA: ResearchInterestCategory[] = [
  {
    category: 'Core Research Domains',
    description: 'Central empirical and theoretical areas demonstrated in Master’s thesis and econometric research papers.',
    interests: [
      {
        name: 'Corporate Governance & Board Structures',
        description: 'Examining board composition, audit committee independence, institutional shareholding, and CEO duality on corporate value and agency costs.',
        keyThemes: ['Audit Committee Independence', 'Institutional Ownership', 'Agency Theory', 'Board Dynamics']
      },
      {
        name: 'Sustainability & ESG Reporting',
        description: 'Investigating environmental, social, and governance disclosures as moderating transmission mechanisms on financial performance and cost of capital.',
        keyThemes: ['ESG Disclosures', 'Stakeholder Theory', 'Moderation Effects', 'Emerging Market Compliance']
      },
      {
        name: 'Financial Econometrics & Panel Data Methods',
        description: 'Application of static and dynamic panel econometric techniques, addressing endogeneity, unobserved heterogeneity, and diagnostic testing.',
        keyThemes: ['Fixed & Random Effects', 'Two-Way Fixed Effects', 'Hausman Testing', 'Diagnostic Robustness']
      },
      {
        name: 'Asset Pricing & Risk-Return Dynamics',
        description: 'Empirical testing of Capital Asset Pricing Model (CAPM), Fama-French multi-factor models, systematic risk (Beta), and portfolio Jensen’s Alpha.',
        keyThemes: ['CAPM Estimation', 'Fama-French Factor Models', 'Market Anomalies', 'Volatility Analysis']
      },
      {
        name: 'Equity Valuation & Financial Modeling',
        description: 'Three-statement financial forecasting, Free Cash Flow to Firm (FCFF) discounted cash flow valuation, WACC computation, and sensitivity modeling.',
        keyThemes: ['FCFF DCF Models', 'WACC Derivation', 'Scenario Analysis', 'Cross-Sector Benchmarking']
      },
      {
        name: 'Corporate Financial Performance & Emerging Markets',
        description: 'Analysis of profitability determinants, capital allocation efficiency, and macroeconomic transitions (e.g. IMF EFF, interest rate cycles) on PSX firms.',
        keyThemes: ['Return on Assets (ROA)', 'Macro-Financial Shocks', 'Emerging Market Efficiency', 'PSX Dynamics']
      }
    ]
  },
  {
    category: 'Emerging Research Interests',
    description: 'Frontier research directions bridging digital innovation, investor psychology, and macroeconomic linkages.',
    interests: [
      {
        name: 'FinTech & Regional Innovation Spillover',
        description: 'Exploring how FinTech adoption mitigates information asymmetry in venture capital and resolves factor market distortions in secondary cities.',
        keyThemes: ['Venture Capital Transmission', 'Resource Allocation Efficiency', 'Quantile Regression', 'Digital Infrastructure']
      },
      {
        name: 'Behavioral Finance & Market Anomalies',
        description: 'Investigating psychological biases, momentum persistence, and adaptive market efficiency during high-volatility macroeconomic transitions.',
        keyThemes: ['Adaptive Market Hypothesis', 'Momentum & Overconfidence', 'Investor Herding', 'Price Discovery']
      },
      {
        name: 'Macro-Financial Linkages & Monetary Policy Transmission',
        description: 'Analyzing the cross-sectional impact of central bank interest rate cycles, sovereign credit agreements, and exchange rate volatility on corporate debt.',
        keyThemes: ['SBP Monetary Easing', 'Discount Rate Impact', 'Leverage & KIBOR Transmission', 'Working Capital Risks']
      }
    ]
  }
];

export const MAJOR_THESIS_PROJECT: ResearchProject = {
  id: 'thesis-master',
  title: 'The Nexus Between Corporate Governance Mechanisms and Corporate Financial Performance: Insights From Pakistan\'s Non-Financial Sector',
  subtitle: 'Master\'s Thesis Research | Institute of Business Administration (IBA), University of the Punjab',
  category: 'Thesis',
  type: 'Academic Empirical Research',
  courseOrContext: 'Master of Business Administration (MBA 1.5) Final Research Thesis',
  supervisorOrFaculty: 'Supervised by: Dr. Yasir Ashraf (Awarded 2nd Position in Master\'s Final Thesis)',
  date: '01/06/2026 – 30/06/2026',
  abstract: `This empirical thesis investigates the relationship between board-level corporate governance mechanisms and corporate financial performance across non-financial companies listed on the Pakistan Stock Exchange (PSX). Employing longitudinal firm-level financial data, the study executes fixed-effects and random-effects panel regressions in STATA to analyze how audit committee independence and institutional shareholding drive corporate Return on Assets (ROA). Furthermore, the research models Sustainability/ESG reporting as a key moderating variable to evaluate whether transparent non-financial disclosures strengthen governance effectiveness and reduce emerging-market agency frictions. Diagnostic evaluations, including multicollinearity (VIF), heteroskedasticity (Breusch-Pagan / modified Wald), and autocorrelation tests, validate the econometric specifications.`,
  researchQuestions: [
    'How do board-level governance structures (audit committee independence, board composition) influence corporate financial performance (ROA) in Pakistan\'s non-financial sector?',
    'Does institutional ownership serve as an effective monitoring mechanism to align management incentives with shareholder wealth in an emerging market setting?',
    'Does sustainability / ESG reporting moderate the relationship between corporate governance mechanisms and return on assets?',
    'Which panel econometric specification (Fixed Effects vs. Random Effects) provides the most consistent and efficient parameter estimates under Hausman testing?'
  ],
  datasetAndSample: {
    period: 'Longitudinal panel data across PSX-listed non-financial sectors',
    sampleSize: 'Multi-year balanced/unbalanced panel of listed non-financial firms',
    frequency: 'Annual firm-level disclosures & financial statements',
    description: 'Cleaned and harmonized financial datasets extracted from audited annual reports, State Bank of Pakistan (SBP) Financial Statement Analysis publications, and PSX company disclosures.',
    entities: ['Textile', 'Cement', 'Chemicals & Fertilizers', 'Automobile', 'Fuel & Energy (Non-financial)']
  },
  methodology: {
    techniques: [
      'Panel Data Econometrics (Fixed Effects & Random Effects)',
      'Moderation Interaction Modeling (Governance × ESG Disclosures)',
      'Hausman Specification Test for Model Consistency',
      'Breusch-Pagan Lagrange Multiplier Test',
      'Diagnostic testing for Multicollinearity, Heteroskedasticity, and Serial Autocorrelation'
    ],
    software: ['STATA', 'SPSS', 'Microsoft Excel'],
    modelsUsed: [
      'Static Panel Regression with FE / RE Estimators',
      'Moderated Linear Panel Model: ROA_{it} = β_0 + β_1 Gov_{it} + β_2 ESG_{it} + β_3 (Gov_{it} × ESG_{it}) + γ Controls_{it} + μ_i + ε_{it}'
    ],
    equations: [
      'ROA_{it} = \\alpha + \\beta_1 (AuditIndep_{it}) + \\beta_2 (InstOwn_{it}) + \\beta_3 (ESG_{it}) + \\beta_4 (Gov_{it} \\times ESG_{it}) + \\sum \\gamma_k Control_{k,it} + \\mu_i + \\varepsilon_{it}'
    ]
  },
  keyVariables: {
    dependent: ['Return on Assets (ROA) — Net Income divided by Total Assets'],
    independent: [
      'Audit Committee Independence (Proportion of independent directors on the audit committee)',
      'Institutional Ownership (% of total outstanding shares held by institutions)'
    ],
    moderating: ['Sustainability / ESG Reporting Index (Disclosures across environmental, social, and corporate governance dimensions)'],
    control: ['Firm Size (ln Total Assets)', 'Financial Leverage (Total Debt / Total Assets)', 'Liquidity (Current Ratio)', 'Firm Age (Years since incorporation)']
  },
  empiricalResults: {
    summary: 'The empirical estimates confirm that audit committee independence and institutional shareholding have a statistically significant positive effect on Return on Assets (ROA). Furthermore, Sustainability/ESG reporting exerts a positive moderating effect, indicating that transparent non-financial reporting amplifies the performance benefits of strong internal governance in Pakistan\'s emerging equity market.',
    metrics: [
      { label: 'Primary Estimation Tool', value: 'STATA (xtreg, fe/re)' },
      { label: 'Dependent Performance Metric', value: 'ROA (Return on Assets)' },
      { label: 'Key Moderating Transmission', value: 'ESG / Sustainability' },
      { label: 'Academic Thesis Distinction', value: '2nd Position in MBA Final Thesis' }
    ]
  },
  diagnosticTests: [
    {
      testName: 'Hausman Specification Test',
      nullHypothesis: 'Random Effects coefficients are consistent and efficient (Cov(μ_i, X_it) = 0)',
      statistic: 'Chi-Square test',
      pValue: 'Determines FE vs RE selection',
      decision: 'Model-dependent selection',
      conclusion: 'Ensures parameter estimates are free from omitted time-invariant endogeneity.'
    },
    {
      testName: 'Multicollinearity Diagnostic (VIF)',
      nullHypothesis: 'No severe linear dependence among regressors (VIF < 5.0 / 10.0)',
      statistic: 'Mean VIF within acceptable bounds',
      pValue: '< 5.0 threshold',
      decision: 'Fail to reject absence of collinearity',
      conclusion: 'No damaging collinearity among governance, ESG, and control variables.'
    },
    {
      testName: 'Modified Wald / Breusch-Pagan for Heteroskedasticity',
      nullHypothesis: 'Homoskedastic disturbance terms across cross-sectional units',
      statistic: 'Chi-Square statistic',
      pValue: 'Tested across sectors',
      decision: 'Robust / Clustered SEs applied if needed',
      conclusion: 'Standard errors adjusted to ensure hypothesis testing validity.'
    }
  ],
  contributionsAndImplications: [
    'Provides empirical evidence from an under-researched emerging market (Pakistan) on how board oversight mitigates agency conflicts.',
    'Demonstrates that ESG reporting is not purely an ethical commitment but a measurable value-enhancing moderating mechanism.',
    'Offers actionable insights for regulatory bodies such as the Securities and Exchange Commission of Pakistan (SECP) regarding governance compliance codes.',
    'Establishes a rigorous foundation for doctoral-level research investigating corporate sustainability, disclosure mandates, and cost of capital.'
  ]
};

export const FEATURED_RESEARCH_PROJECTS: ResearchProject[] = [
  MAJOR_THESIS_PROJECT,
  {
    id: 'psx-econometrics-capm',
    title: 'Financial Econometrics: PSX Equity Analysis, Descriptive Statistics, Volatility, & CAPM Estimation',
    subtitle: 'MBA609 Financial Econometrics Report | Submitted to Dr. Humaira Asad, IBA University of the Punjab',
    category: 'Financial Econometrics',
    type: 'Academic Empirical Research',
    courseOrContext: 'MBA609 Financial Econometrics, IBA University of the Punjab',
    supervisorOrFaculty: 'Dr. Humaira Asad (MBA 1.5, Roll No: 2024-047)',
    date: '02/03/2026 – 20/03/2026 (Data Period: June 2024 – May 2026)',
    abstract: `An econometric study analyzing a balanced panel dataset of 120 monthly observations (N = 5 PSX-listed blue-chip firms across 5 distinct economic sectors over T = 24 monthly periods: June 2024 to May 2026) benchmarked against the KSE-100 index. The paper computes simple and log returns (LRLUCK = 100*ln(LUCK/L.LUCK)), models time-series trajectories (tsline), assesses volatility distributions, evaluates weak-form Efficient Market Hypothesis (EMH), and executes an in-depth CAPM regression on Oil and Gas Development Company (OGDC) in STATA 15 with full Breusch-Pagan heteroskedasticity and Breusch-Godfrey LM autocorrelation diagnostic testing. It includes a critical review of FinTech collaborative innovation channels (Lian, 2026) using Two-Way Fixed Effects, Instrumental Variables, and Quantile Regressions.`,
    researchQuestions: [
      'How did the July 2024 IMF EFF ($7B) approval and SBP 1,000-bps rate cuts influence cross-sectoral equity trajectories on the PSX?',
      'Does the Capital Asset Pricing Model (Sharpe-Lintner-Black) reliably price systematic market risk for OGDC against the KSE-100 benchmark?',
      'Are OLS standard errors and inference valid under rigorous Breusch-Pagan and Breusch-Godfrey diagnostic tests?',
      'Does empirical PSX return behavior align with Weak-Form Efficient Market Hypothesis or support Behavioral Finance momentum anomalies?'
    ],
    datasetAndSample: {
      period: 'June 2024 – May 2026 (24 monthly periods)',
      sampleSize: 'Balanced panel of 120 observations (5 firms × 24 months)',
      frequency: 'Monthly closing price series',
      description: 'Historical closing prices sourced from Investing.com for LUCK, OGDC, PSO, FFC, HBL, and the benchmark KSE-100 index.',
      entities: [
        'Lucky Cement Ltd. (LUCK) — Construction',
        'Oil & Gas Development Company Limited (OGDC) — Upstream Energy',
        'Pakistan State Oil (PSO) — Downstream Petroleum',
        'Fauji Fertilizer Company (FFC) — Fertilizers',
        'Habib Bank Limited (HBL) — Banking',
        'KSE-100 Index (Benchmark: 77,887 to 184,175 points, +135%)'
      ]
    },
    methodology: {
      techniques: [
        'Panel and Time-Series Data Structuring (Stata tsset)',
        'Logarithmic Returns Transformation: generate LRLUCK = 100*ln(LUCK/L.LUCK)',
        'Ordinary Least Squares (OLS) CAPM Regression: regress LROGDC LRKSE',
        'Heteroskedasticity Diagnostics: estat hettest (Breusch-Pagan / Cook-Weisberg)',
        'Serial Correlation Diagnostics: estat bgodfrey, lags(1 2 3) (Breusch-Godfrey LM test)',
        'Quantile Regression & Two-Way Fixed Effects Synthesis'
      ],
      software: ['STATA 15', 'Microsoft Excel'],
      modelsUsed: [
        'CAPM Model: R_{OGDC,t} - R_{f,t} = \\alpha + \\beta (R_{KSE,t} - R_{f,t}) + \\varepsilon_t',
        'Breusch-Pagan Auxiliary Model: e_i^2 = \\delta_0 + \\delta_1 \\hat{y}_i + v_i',
        'Breusch-Godfrey LM Model: e_t = \\rho_1 e_{t-1} + \\rho_2 e_{t-2} + \\dots + v_t'
      ]
    },
    empiricalResults: {
      summary: 'The CAPM regression for OGDC demonstrates robust market co-movement. Beta is estimated at 1.127 (p < 0.001), showing mildly aggressive / near market-neutral behavior. Alpha is -0.0168 (p = 0.990), confirming that OGDC is fairly priced without abnormal Jensen\'s Alpha. R² of 0.6699 indicates that 67% of OGDC return variation is explained by the KSE-100.',
      metrics: [
        { label: 'OGDC Beta (β)', value: '1.127', note: 't = 6.53, p < 0.001 (95% CI: [0.768, 1.486])' },
        { label: 'OGDC Alpha (α)', value: '-0.0168', note: 't = -0.01, p = 0.990 (Fairly priced)' },
        { label: 'Model R-Squared', value: '0.6699', note: '67% variance explained by market' },
        { label: 'F-Statistic', value: '42.62', note: 'p < 0.001 (Jointly significant at 1%)' },
        { label: 'Root MSE', value: '5.3714', note: 'Avg monthly prediction error' },
        { label: 'KSE-100 24-Mo Gain', value: '+135%', note: '77,887 to 184,175 points' }
      ],
      tables: [
        {
          title: 'Table 1: Descriptive Statistics of Monthly Stock Prices (N = 24 per series)',
          headers: ['Variable', 'Mean', 'Median (p50)', 'Std. Dev.', 'Min', 'Max', 'N'],
          rows: [
            ['KSE-100 Index', '129,881', '122,659', '34,910', '77,887', '184,175', 24],
            ['LUCK (PKR)', '546.16', '455.84', '262.59', '236.17', '1,100.49', 24],
            ['PSO (PKR)', '348.06', '367.48', '103.71', '159.50', '474.16', 24],
            ['OGDC (PKR)', '229.43', '229.99', '58.86', '129.06', '330.33', 24],
            ['FFC (PKR)', '404.45', '394.93', '131.82', '163.20', '590.71', 24],
            ['HBL (PKR)', '214.15', '180.10', '76.31', '124.00', '343.90', 24]
          ],
          note: 'LUCK standard deviation reflects January 2025 stock split (PKR 1,100 to 236).'
        },
        {
          title: 'Table 2: Volatility Ranking (Standard Deviation of Log Returns)',
          headers: ['Rank', 'Company', 'Ticker', 'SD Log Returns (%)', 'Volatility Level', 'Primary Driver'],
          rows: [
            ['1st', 'Lucky Cement Ltd.', 'LUCK', '34.06%', 'Extremely High', 'Jan 2025 stock split structural break'],
            ['2nd', 'Pakistan State Oil', 'PSO', '16.05%', 'High', 'Oil price cycles & fuel subsidy removal'],
            ['3rd', 'Habib Bank Ltd.', 'HBL', '11.64%', 'Moderate', 'Interest rate cycle & credit recovery'],
            ['4th', 'Fauji Fertilizer Co.', 'FFC', '9.44%', 'Low', 'Stable agricultural demand & consistent dividends'],
            ['5th', 'OGDC', 'OGDC', '9.13%', 'Lowest', 'Government-backed upstream revenue predictability']
          ]
        },
        {
          title: 'Table 3: CAPM Regression Parameter Estimates (OGDC on KSE-100)',
          headers: ['Parameter', 'Coefficient', 'Std. Error', 't-Statistic', 'p-Value', '95% Conf. Interval'],
          rows: [
            ['Alpha (α) — Constant', '-0.0168', '1.2695', '-0.01', '0.990', '[-2.657, 2.623]'],
            ['Beta (β) — LRKSE', '1.1270', '0.1726', '6.53', '0.000***', '[0.768, 1.486]']
          ],
          note: '*** Indicates statistical significance at the 1% level (p < 0.001).'
        }
      ]
    },
    diagnosticTests: [
      {
        testName: 'Breusch-Pagan / Cook-Weisberg Test for Heteroskedasticity',
        nullHypothesis: 'Constant error variance (Homoskedasticity: Var(ε_i|X) = σ²)',
        statistic: 'chi2(1) = 1.34',
        pValue: '0.2467',
        decision: 'Fail to reject H0 (p > 0.05)',
        conclusion: 'No heteroskedasticity detected. OLS standard errors and t-statistics are reliable for statistical inference.'
      },
      {
        testName: 'Breusch-Godfrey LM Test for Autocorrelation (Lag 1)',
        nullHypothesis: 'No first-order serial correlation in residuals (Cov(ε_t, ε_{t-1}) = 0)',
        statistic: 'chi2(1) = 0.434',
        pValue: '0.5101',
        decision: 'Fail to reject H0 (p > 0.05)',
        conclusion: 'Residuals are serially independent. OLS estimates are efficient.'
      },
      {
        testName: 'Breusch-Godfrey LM Test for Autocorrelation (Lag 2)',
        nullHypothesis: 'No second-order serial correlation',
        statistic: 'chi2(2) = 0.507',
        pValue: '0.7760',
        decision: 'Fail to reject H0 (p > 0.05)',
        conclusion: 'Residual independence confirmed at lag 2.'
      },
      {
        testName: 'Breusch-Godfrey LM Test for Autocorrelation (Lag 3)',
        nullHypothesis: 'No third-order serial correlation',
        statistic: 'chi2(3) = 0.508',
        pValue: '0.9171',
        decision: 'Fail to reject H0 (p > 0.05)',
        conclusion: 'Residual independence confirmed at lag 3.'
      }
    ],
    contributionsAndImplications: [
      'Empirical validation of CAPM applicability in Pakistan\'s emerging equity market for large-cap state-backed entities.',
      'Documented evidence on market efficiency violations: while OGDC and FFC exhibit random walk behavior, LUCK (post-split adjustment), PSO (+185% surge), and HBL (+91% breakout) support behavioral momentum persistence.',
      'Critically synthesized macroeconomic transmission: IMF EFF $7B program and 1,000-bps SBP rate cut cycle as primary catalyst for market re-rating.',
      'Policy extension analyzing FinTech quantile regression results (Lian 2026), highlighting highest marginal gains in secondary industrial cities (Faisalabad, Sialkot, Multan).'
    ]
  },
  {
    id: 'ogdcl-pol-valuation',
    title: 'Upstream Oil & Gas Financial Modeling, FCFF DCF Valuation & Peer Analysis: OGDCL vs POL',
    subtitle: 'Comprehensive 17-Page Three-Statement Financial Model & Valuation Report',
    category: 'Equity Valuation',
    type: 'Applied Financial Valuation',
    courseOrContext: 'Pakistan Upstream Oil & Gas Financial Modeling & Equity Research Project',
    supervisorOrFaculty: 'Author: Muhammad Waqas (March 2026 | PSX: OGDC / POL)',
    date: '15/05/2026 – 10/06/2026 (March 2026 Report)',
    abstract: `A comprehensive 17-page three-statement financial analysis and Free Cash Flow to Firm (FCFF) discounted cash flow (DCF) valuation of Oil and Gas Development Company Limited (OGDCL), Pakistan's largest upstream exploration and production company (69% government ownership), benchmarked against Pakistan Oilfields Limited (POL). The 13-sheet workbook incorporates historical statements (FY2022–FY2024), 14 financial ratios, common-size analysis, a 3-year driver-based projection (FY2025–FY2027), WACC estimation (26.48% based on Damodaran ERP 13.94% and 10-year bond yield 11.56%), and a 5×5 sensitivity matrix. Intrinsic value per share is established at PKR 207 against a market price of PKR 135 (+53% upside, BUY recommendation).`,
    researchQuestions: [
      'What is the fundamental intrinsic value of OGDCL using a robust FCFF DCF framework with zero interest-bearing debt?',
      'How do the operating leverage, capital structure, and profitability profiles of state-owned OGDCL compare to private-sector peer POL?',
      'How sensitive is OGDCL\'s valuation to variations in the Weighted Average Cost of Capital (14%–22%) and terminal growth rate (2%–6%)?',
      'What are the key working capital and circular debt risks impacting OGDCL\'s receivables (PKR 635 billion, 137% of revenue)?'
    ],
    datasetAndSample: {
      period: 'FY2022 – FY2024 Historical; FY2025 – FY2027 Forward Projections',
      sampleSize: 'Full audited financial statements & 13-sheet Excel model',
      frequency: 'Annual corporate filings & daily market prices',
      description: 'Audited annual reports of OGDCL and POL, State Bank of Pakistan interest rate releases, TradingView beta estimates, and Aswath Damodaran (NYU Stern) country risk premium data.',
      entities: ['Oil & Gas Development Company Limited (OGDCL, PSX: OGDC)', 'Pakistan Oilfields Limited (POL, PSX: POL)']
    },
    methodology: {
      techniques: [
        'Integrated Three-Statement Modeling (Income Statement, Balance Sheet, Cash Flow Statement)',
        'Unlevered Free Cash Flow to Firm (FCFF): FCFF = NOPAT - CAPEX - ΔNWC',
        'Weighted Average Cost of Capital (WACC) Calculation: Ke = Rf + β × ERP',
        'Gordon Growth Terminal Value Modeling: TV = FCFF_2027 × (1+g) / (WACC - g)',
        'Common-Size Financial Statement Normalization (% of Revenue & % of Assets)',
        'Two-Dimensional WACC vs. Terminal Growth Rate Sensitivity Matrix'
      ],
      software: ['Microsoft Excel (13 Sheets)', 'Financial Modeling Frameworks'],
      modelsUsed: [
        'CAPM Cost of Equity: 11.56% + 1.07 × 13.94% = 26.48%',
        'Enterprise Value = \\sum_{t=1}^3 \\frac{FCFF_t}{(1+WACC)^t} + \\frac{TerminalValue}{(1+WACC)^3}',
        'Equity Value = Enterprise Value - Net Debt (Net Cash Added: +PKR 259,001 mn)'
      ]
    },
    empiricalResults: {
      summary: 'OGDCL exhibits tremendous balance sheet strength with zero interest-bearing debt and net cash of PKR 259 billion. DCF model establishes an enterprise value of PKR 633,117 mn and equity value of PKR 892,117 mn, yielding an intrinsic value of PKR 207 per share (+53% upside vs market price PKR 135). Peer comparison shows OGDCL operates at 7x the scale of POL, with attractive P/E of 2.8x vs POL\'s 6.1x.',
      metrics: [
        { label: 'OGDCL DCF Target Price', value: 'PKR 207 / share', note: '53% discount to intrinsic value (BUY)' },
        { label: 'Market Price (FY2024)', value: 'PKR 135 / share', note: 'Year-end PSX closing' },
        { label: 'Enterprise Value (EV)', value: 'PKR 633,117 mn', note: 'PV of FCFF + PV of Terminal Value' },
        { label: 'Net Cash Position', value: 'PKR 259,001 mn', note: 'Zero debt fortress balance sheet' },
        { label: 'Equity Value', value: 'PKR 892,117 mn', note: 'EV + Net Cash' },
        { label: 'FY2024 Revenue', value: 'PKR 463,698 mn', note: '+38.2% two-year cumulative growth' },
        { label: 'FY2024 Net Profit', value: 'PKR 208,976 mn', note: 'Net profit margin: 45.1%' },
        { label: 'EBIT Margin (FY24)', value: '64.9%', note: 'High operating profitability' },
        { label: 'WACC / Cost of Equity', value: '26.48%', note: 'Rf=11.56%, β=1.07, ERP=13.94%' }
      ],
      tables: [
        {
          title: 'Three-Statement Financial Performance: OGDCL (PKR Millions)',
          headers: ['Line Item', 'FY2022', 'FY2023', 'FY2024', 'Growth FY23', 'Growth FY24'],
          rows: [
            ['Revenue', '335,464', '413,594', '463,698', '+23.3%', '+12.1%'],
            ['Cost of Sales', '118,548', '143,867', '180,385', '+21.4%', '+25.4%'],
            ['Gross Profit', '216,916', '269,727', '283,313', '+24.4%', '+5.0%'],
            ['EBIT', '234,862', '388,488', '300,930', '+65.4%', '-22.5%'],
            ['Net Profit', '133,784', '224,618', '208,976', '+67.9%', '-7.0%'],
            ['Cash & Equivalents', '31,631', '25,766', '141,030', '-18.5%', '+346.0%'],
            ['Total Equity', '875,393', '1,082,898', '1,250,496', '+23.7%', '+15.5%'],
            ['Total Assets', '1,129,983', '1,424,066', '1,604,254', '+26.0%', '+12.7%']
          ]
        },
        {
          title: 'Peer Benchmarking: OGDCL vs. POL (FY2024)',
          headers: ['Metric', 'OGDCL', 'POL', 'Relative Advantage', 'Analytical Commentary'],
          rows: [
            ['Revenue', 'PKR 463,698 mn', 'PKR 65,290 mn', 'OGDCL (Scale)', 'OGDCL is ~7x larger by revenue'],
            ['EBIT Margin', '64.9%', '86.7%', 'POL (Efficiency)', 'POL benefits from low-cost Potohar fields'],
            ['Net Profit', 'PKR 208,976 mn', 'PKR 39,152 mn', 'OGDCL (Absolute)', 'OGDCL generates massive absolute cash flow'],
            ['Net Margin', '45.1%', '60.0%', 'POL (Margin)', 'POL is more margin-efficient'],
            ['ROE (FY24)', '16.7%', '47.3%', 'POL (Return)', 'POL generates higher return on equity'],
            ['Debt / Equity', '0.28x', '1.12x', 'OGDCL (Safety)', 'OGDCL holds zero interest-bearing debt'],
            ['P/E Ratio', '2.8x', '6.1x', 'OGDCL (Value)', 'OGDCL trades at deep valuation discount']
          ]
        },
        {
          title: 'DCF Sensitivity Matrix: Implied Value / Share (PKR) vs. WACC & Terminal Growth (g)',
          headers: ['g \\ WACC', '14%', '16%', '18%', '20%', '22%'],
          rows: [
            ['2.0%', '304', '273', '250', '231', '215'],
            ['3.0%', '365', '318', '284', '258', '237'],
            ['4.0% (Base)', '390', '335', '296', '267', '244'],
            ['5.0%', '421', '355', '310', '277', '252'],
            ['6.0%', '459', '379', '327', '289', '260']
          ],
          note: 'Under conservative assumptions (WACC=22%, g=2%), value of PKR 215 is 59% above market price (PKR 135).'
        }
      ]
    },
    contributionsAndImplications: [
      'Demonstrates advanced mastery of three-statement financial modeling and DCF valuation architecture.',
      'Highlights working capital risks in emerging state-owned enterprises where receivables constitute 137% of revenue due to energy sector circular debt.',
      'Synthesizes macroeconomic discount rate dynamics: showing how falling sovereign yields dramatically unlock equity value in capital-intensive sectors.'
    ]
  },
  {
    id: 'fcepl-equity-research',
    title: 'Equity Research Report: FrieslandCampina Engro Pakistan Ltd (FCEPL)',
    subtitle: 'FMCG / Dairy & Beverages Sector | Rating: HOLD | Target Price: PKR 148',
    category: 'Equity Valuation',
    type: 'Applied Financial Valuation',
    courseOrContext: 'Pakistan Equity Research Programme — Phase 4 (March 2026)',
    supervisorOrFaculty: 'Muhammad Waqas (Equity Research Analyst)',
    date: 'March 2026',
    abstract: `An institutional equity research report evaluating FrieslandCampina Engro Pakistan Limited (FCEPL, Pakistan's second-largest UHT dairy producer with brands Olper's, Tarang, Omung, and Nurpur). Initiated with a 12-month HOLD rating and target price of PKR 148 (current market price PKR 162, -8.6% downside). The investment thesis evaluates a 3-pillar margin recovery: (1) Dairy raw material cost normalization (gross margin expansion from 20% to 22–24%), (2) SBP interest rate cut relief on PKR 11.3bn floating debt (saving PKR 170–340mn annually), and (3) Fixed-cost operating leverage. Includes scenario modeling (Bull: PKR 242, Base: PKR 148, Bear: PKR 88) and comprehensive ESG evaluation.`,
    researchQuestions: [
      'How will raw milk procurement stabilization and currency equilibrium affect FCEPL\'s gross margins over FY2025–2027?',
      'What is the quantifiable impact of SBP monetary easing (150–300 bps rate cuts) on FCEPL\'s floating-rate interest burden?',
      'What is the intrinsic value under FCFF DCF valuation with WACC of 16.3% and terminal growth of 5.5%?'
    ],
    datasetAndSample: {
      period: 'FY2022A – FY2024A Historical; FY2025E – FY2027E Forecasts',
      sampleSize: '6-year full financial summary & quarterly operational metrics',
      frequency: 'Annual & quarterly financial reports',
      description: 'Audited statements of FCEPL, Pakistan Dairy Association industry data, and State Bank of Pakistan interest rate releases.',
      entities: ['FrieslandCampina Engro Pakistan Ltd (PSX: FCEPL)']
    },
    methodology: {
      techniques: [
        'FCFF DCF Valuation with WACC = 16.3% (Rf = 13.75%, ERP = 5.50%, Beta = 0.72x)',
        'Three-Case Scenario Analysis (Bull / Base / Bear)',
        'Working Capital Cycle Analysis (DSO 29.9 days, DIO 57.3 days, CCC 40.2 days in FY24)',
        'ESG Framework Assessment (Environmental: 3/5, Social: 4/5, Governance: 3.5/5)'
      ],
      software: ['Microsoft Excel', 'Financial Modeling Frameworks'],
      modelsUsed: ['DCF Model: Ke = 13.75% + 0.72 × 5.50% = 17.7%; WACC = 16.3%']
    },
    empiricalResults: {
      summary: 'At PKR 162, the market has priced in modest margin recovery. Base case target of PKR 148 indicates HOLD. Bull case targets PKR 242 (+49%) if gross margin reaches 25% and SBP cuts 300bps. Bear case targets PKR 88 (-46%) if currency depreciates further.',
      metrics: [
        { label: 'Rating', value: 'HOLD', note: '12-month horizon' },
        { label: 'Target Price', value: 'PKR 148', note: 'Base DCF Intrinsic Value' },
        { label: 'Current Price', value: 'PKR 162', note: 'Upside / Downside: -8.6%' },
        { label: 'FY24A Revenue', value: 'PKR 78,420 mn', note: '~20% 4-year CAGR' },
        { label: 'FY24A Gross Margin', value: '20.0%', note: 'Target: 22-24% by FY27' },
        { label: 'WACC Assumption', value: '16.3%', note: 'Rf=13.75%, Beta=0.72x, ERP=5.50%' },
        { label: 'Bull Case Target', value: 'PKR 242 (+49%)', note: 'Accelerated volume & 25% GM' },
        { label: 'Bear Case Target', value: 'PKR 88 (-46%)', note: 'Input cost inflation & high debt' }
      ]
    },
    contributionsAndImplications: [
      'Detailed financial evaluation of consumer staples pricing power and formal sector penetration in Pakistan (<15% vs India ~45%).',
      'Integration of ESG performance metrics with fundamental DCF financial models.'
    ]
  },
  {
    id: 'nfl-equity-research',
    title: 'Equity Research Report: National Foods Limited (NFL)',
    subtitle: 'FMCG / Spices, Condiments & Recipe Mixes | Rating: BUY | Target Price: PKR 680',
    category: 'Equity Valuation',
    type: 'Applied Financial Valuation',
    courseOrContext: 'Pakistan Equity Research Programme — Phase 4 (March 2026)',
    supervisorOrFaculty: 'Muhammad Waqas (Equity Research Analyst)',
    date: 'March 2026',
    abstract: `An institutional equity research report on National Foods Limited (NFL), Pakistan's pre-eminent branded food company (300+ SKUs across spices, recipe mixes, sauces, and pickles). Initiated with a BUY rating and 12-month target price of PKR 680 (+11.5% upside vs PKR 610). The thesis is founded on three pillars: (1) Unrivaled brand moat in sticky categories (aided awareness >70%), (2) Rapid export expansion (25–30% annual growth targeting South Asian diaspora in US, UK, Canada, and Gulf with premium gross margins of 35–40%), and (3) Debt servicing relief from SBP interest rate reductions on PKR 8.5bn debt. Valuation is built on FCFF DCF with WACC of 17.1% and scenario analysis (Bull: PKR 980, Base: PKR 680, Bear: PKR 420).`,
    researchQuestions: [
      'How does NFL\'s brand loyalty and pricing power protect margins against agricultural raw material inflation?',
      'What is the margin accretion trajectory as export revenue grows from ~10% to 25–30% of total revenue by FY2027?',
      'What is the fundamental equity value using FCFF DCF modeling with WACC = 17.1% and terminal growth = 5.5%?'
    ],
    datasetAndSample: {
      period: 'FY2022A – FY2024A Historical; FY2025E – FY2027E Forecasts',
      sampleSize: '6-year financial performance models and export market breakdowns',
      frequency: 'Annual audited financial reports',
      description: 'Audited financial statements of National Foods Limited, export trade statistics, and sector peer multiples.',
      entities: ['National Foods Limited (PSX: NFL)']
    },
    methodology: {
      techniques: [
        'FCFF DCF Valuation (WACC = 17.1%, Rf = 13.75%, ERP = 5.50%, Beta = 0.85x)',
        'Brand Moat & Pricing Power Analysis in Consumer Staples',
        'Export Segment Margin Accretion Modeling',
        'Scenario Analysis (Bull: PKR 980, Base: PKR 680, Bear: PKR 420)',
        'ESG Assessment (Environmental: 3/5, Social: 4/5, Governance: 3/5)'
      ],
      software: ['Microsoft Excel', 'DCF Financial Modeling Templates'],
      modelsUsed: ['Ke = 13.75% + 0.85 × 5.50% = 18.4%; WACC = 17.1%']
    },
    empiricalResults: {
      summary: 'NFL represents a high-quality compounder with durable brand strength. Valuation yields a target of PKR 680 (BUY). Export growth at 25-30% with 35-40% gross margins provides a major valuation re-rating catalyst toward 28-32x P/E.',
      metrics: [
        { label: 'Rating', value: 'BUY', note: '12-month investment horizon' },
        { label: 'Target Price', value: 'PKR 680', note: '+11.5% upside from PKR 610' },
        { label: 'Bull Case Target', value: 'PKR 980', note: '+61% upside on export surge' },
        { label: 'FY24A Revenue', value: 'PKR 38,420 mn', note: '15-17% 5-year CAGR' },
        { label: 'Gross Margin (FY24)', value: '29.5%', note: 'Stable pricing power' },
        { label: 'ROE (FY24A)', value: '26.6%', note: 'Exceptional equity return' },
        { label: 'Export Gross Margin', value: '35–40%', note: 'vs domestic 26–28%' }
      ]
    },
    contributionsAndImplications: [
      'Empirical analysis of brand moat and consumer habit resistance to down-trading during high-inflation economic regimes.',
      'Quantitative modeling of international diaspora export strategies as an earnings stabilizer for emerging market corporations.'
    ]
  },
  {
    id: 'multi-factor-portfolio-risk',
    title: 'Multi-Factor Risk-Return Analysis & Portfolio Management: JPM, NVDA, and KO vs. S&P 500',
    subtitle: 'MBAH-511 Investment Analysis and Portfolio Management | Submitted to Dr. Naseem Bukhari',
    category: 'Portfolio & Risk',
    type: 'Academic Empirical Research',
    courseOrContext: 'MBAH-511 Investment Analysis and Portfolio Management, IBA University of the Punjab',
    supervisorOrFaculty: 'Submitted to: Dr. Naseem Bukhari (6th June, 2025)',
    date: '15/05/2026 – 10/06/2026 (Submitted June 2025)',
    abstract: `An empirical asset pricing and portfolio risk study analyzing 751 daily observations (April 30, 2023 to April 30, 2025) for JPMorgan Chase & Co. (JPM), NVIDIA Corporation (NVDA), and The Coca-Cola Company (KO) benchmarked against the S&P 500 index. The project evaluates 2-year price performance, daily returns, standard deviation, and covariance structures, estimates Fama-French multi-factor regressions to decompose stock returns into systematic market and firm-specific idiosyncratic risk components, and computes portfolio-level Jensen\'s Alpha via CAPM regression against the S&P 500.`,
    researchQuestions: [
      'How do multi-factor Fama-French specifications explain the cross-section of daily returns across diverse sectors (Banking, Tech/Semiconductors, Consumer Staples)?',
      'What proportion of return variation is driven by systematic factor risk versus idiosyncratic firm-specific innovation?',
      'Does an actively managed multi-asset portfolio generate statistically significant positive Jensen\'s Alpha relative to the S&P 500?'
    ],
    datasetAndSample: {
      period: 'April 30, 2023 – April 30, 2025 (2-Year daily series)',
      sampleSize: '751 daily observations per equity and market index',
      frequency: 'Daily trading returns and market factors',
      description: 'Historical closing prices, daily returns, Fama-French factors, and S&P 500 benchmark data.',
      entities: [
        'JPMorgan Chase & Co. (JPM) — Financial Services ($136.94 → $253.47, +85.1%)',
        'NVIDIA Corporation (NVDA) — Technology / Semiconductors ($27.74 → $117.37, +323.2%)',
        'The Coca-Cola Company (KO) — Consumer Staples ($63.99 → $71.17, +11.2%)',
        'S&P 500 Index (Benchmark: Annualized Return 13.13%, Daily SD 1.1022%)'
      ]
    },
    methodology: {
      techniques: [
        'Daily Arithmetic Return & Volatility Estimation',
        'Fama-French Multi-Factor Regression Modeling (751 observations)',
        'CAPM Regression & Jensen\'s Alpha Estimation: R_{p,t} - R_{f,t} = \\alpha + \\beta (R_{m,t} - R_{f,t}) + \\varepsilon_t',
        'ANOVA Decomposition of Regression and Residual Sum of Squares'
      ],
      software: ['Microsoft Excel', 'Statistical Factor Analysis Workbooks'],
      modelsUsed: [
        'Fama-French Factor Regressions: R_i - R_f = \\alpha_i + \\beta_{i1}(R_m - R_f) + \\beta_{i2}SMB + \\beta_{i3}HML + \\beta_{i4}WML + \\varepsilon_i',
        'Jensen\'s Alpha Model: Intercept \\alpha captures risk-adjusted abnormal performance'
      ]
    },
    empiricalResults: {
      summary: 'Empirical results show marked heterogeneity in factor explanatory power. JPM exhibits CAPM Beta = 0.865 (p < 0.001) with R² = 37.74%, while Fama-French R² is only 2.85%, indicating substantial idiosyncratic banking factors. NVDA is almost completely uncorrelated with traditional market factors (Fama-French R² = 0.89%), with returns driven by tech innovation sentiment. KO exhibits stable defensive properties (Daily SD = 0.984%, Fama-French R² = 8.91%). At the portfolio level, active management generated statistically significant positive Jensen\'s Alpha (α = 0.0150, t = 12.15, p < 0.001) with R² = 50.27% against the S&P 500.',
      metrics: [
        { label: 'JPM 2-Yr Return', value: '+85.1%', note: '$136.94 to $253.47 | Daily SD: 1.574%' },
        { label: 'NVDA 2-Yr Return', value: '+323.2%', note: '$27.74 to $117.37 | Daily SD: 3.481%' },
        { label: 'KO 2-Yr Return', value: '+11.2%', note: '$63.99 to $71.17 | Daily SD: 0.984%' },
        { label: 'Portfolio Jensen\'s Alpha', value: '0.0150', note: 't = 12.15, p < 0.001 (Positive alpha)' },
        { label: 'Portfolio CAPM Beta', value: '2.192', note: 't = 27.52, p < 0.001 (S&P 500)' },
        { label: 'Portfolio R-Squared', value: '50.27%', note: 'F = 757.12, p < 0.001 (751 obs)' }
      ],
      tables: [
        {
          title: 'Asset Profile Summary (April 30, 2023 – April 30, 2025)',
          headers: ['Metric', 'JPMorgan Chase (JPM)', 'Coca-Cola (KO)', 'NVIDIA (NVDA)', 'S&P 500 Market'],
          rows: [
            ['2-Year Price Change', '+$116.53 (+85.1%)', '+$7.18 (+11.2%)', '+$89.63 (+323.2%)', 'Benchmark Index'],
            ['Avg Daily Return', '0.0758%', '0.0229%', '0.2623%', '0.0338% (Ann: 13.13%)'],
            ['Daily Std. Deviation', '1.5743%', '0.9840%', '3.4810%', '1.1022%'],
            ['Fama-French R²', '2.85%', '8.91%', '0.89%', 'Factor Model Fit'],
            ['Risk Level', 'Moderate', 'Low (Defensive)', 'Very High (Growth)', 'Market Level'],
            ['Return Potential', 'Medium', 'Low', 'High', 'Broad Market'],
            ['Optimal Portfolio Role', 'Balanced Core', 'Capital Preservation', 'Aggressive Growth', 'Benchmark']
          ]
        },
        {
          title: 'Portfolio-Level Jensen\'s Alpha & CAPM Regression Summary (751 Observations)',
          headers: ['Parameter', 'Coefficients', 'Standard Error', 't-Stat', 'p-Value', '95% Confidence Interval'],
          rows: [
            ['Intercept (Alpha α)', '0.015019', '0.001236', '12.15', '3.94E-31***', '[0.01259, 0.01745]'],
            ['Slope (Beta β)', '2.192303', '0.079674', '27.52', '1.00E-115***', '[2.03589, 2.34872]']
          ],
          note: '*** Statistically significant at the 1% level. R² = 0.5027, Adjusted R² = 0.5020, F = 757.12.'
        }
      ]
    },
    contributionsAndImplications: [
      'Demonstrates that market factor models explain very little variation in high-growth disruptive technology equities (NVDA R² < 1%), highlighting the necessity of industry-specific innovation proxies.',
      'Validates portfolio construction techniques that blend defensive consumer staples with financial core and growth assets to attain positive risk-adjusted Jensen\'s Alpha.'
    ]
  }
];

export const EDUCATION_DATA: EducationItem[] = [
  {
    degree: 'Master of Business Administration (MBA 1.5)',
    institution: 'University of the Punjab',
    location: 'Lahore, Pakistan',
    campus: 'Institute of Business Administration (IBA), Quaid-e-Azam Campus',
    dates: '01/10/2024 – Current (Batch: 2024–2026)',
    cgpa: '3.35',
    maxGpa: '4.00',
    field: 'Finance',
    thesisTitle: 'The Nexus Between Corporate Governance Mechanisms and Corporate Financial Performance: Insights From Pakistan\'s Non-Financial Sector',
    supervisor: 'Dr. Yasir Ashraf',
    distinctions: [
      '1st Position in Managerial Economics',
      '2nd Position in Master\'s Final Thesis'
    ],
    keyCourses: [
      'Financial Econometrics',
      'Investment Analysis & Portfolio Management',
      'Corporate Finance',
      'Managerial Economics',
      'Advanced Research Methodology',
      'Financial Modeling & Valuation'
    ]
  },
  {
    degree: 'Bachelor of Business Administration (BBA)',
    institution: 'University of Education, Lahore',
    location: 'Multan, Pakistan',
    campus: 'Multan Campus (Gulgasht Colony, Bosan Road)',
    dates: '26/10/2020 – 22/08/2024',
    cgpa: '3.13',
    maxGpa: '4.00',
    field: 'Finance',
    distinctions: [
      'Lead Organizer, Departmental Academic & Cultural Assemblies',
      'Merit-based coursework standing in Core Business & Quantitative modules'
    ],
    keyCourses: [
      'Business Finance & Financial Management',
      'Statistical Inference & Business Mathematics',
      'Financial Accounting & Auditing',
      'Principles of Micro & Macroeconomics',
      'Business Research Methods'
    ]
  }
];

export const TEACHING_EXPERIENCE_DATA: TeachingExperienceItem[] = [
  {
    role: 'Student Instructor — Research Methods & Statistical Software',
    institution: 'Institute of Business Administration (IBA), University of the Punjab',
    location: 'Lahore, Pakistan',
    dates: '04/11/2024 – Current',
    audience: 'Graduate (Master\'s) and Junior Research Students',
    subjects: ['STATA Econometric Routines', 'SPSS Data Analysis', 'Reference Management (Zotero, Mendeley)', 'Panel Data Regression'],
    highlights: [
      'Instruct fellow and junior graduate students in statistical software applications (STATA, SPSS) for empirical research projects.',
      'Lead hands-on tutorials on data entry, variable transformation, cross-sectional/panel data routines, and econometric interpretation of regression outputs.',
      'Mentor peers in academic literature sourcing, systematic literature reviews, reference management (Zotero, Mendeley), and research paper structuring.'
    ]
  },
  {
    role: 'Founder & Academic Tutor',
    institution: 'Elevate Academy',
    location: 'Online / Hybrid',
    dates: '15/08/2026 – Current',
    audience: 'University Undergraduates & Thesis-Level Business Students',
    subjects: ['Corporate Finance', 'Econometrics', 'Financial Accounting', 'Thesis Research Design'],
    highlights: [
      'Deliver specialized online instruction in Finance, Economics, and Accounting related subjects.',
      'Provide individualized guidance on quantitative research design, hypothesis formulation, and statistical analysis for thesis-level business and finance students.'
    ]
  },
  {
    role: 'Lecturer — Accounting, Finance & Economics (Intermediate & ADP)',
    institution: 'Islamic College of Science & Arts',
    location: 'Shujabad, Multan, Pakistan',
    dates: '01/12/2025 – 15/05/2026',
    audience: 'Intermediate (I.Com) & Associate Degree Program (ADP) Students',
    subjects: ['Principles of Accounting', 'Business Finance', 'Microeconomics & Macroeconomics'],
    highlights: [
      'Taught core Accounting, Finance, and Economics curricula to Intermediate (I.Com) and ADP-level student cohorts.',
      'Designed examination assessments, quantitative problem sets, and interactive lectures translating theoretical economic models into real-world business context.'
    ]
  },
  {
    role: 'Volunteer Instructor — Free Summer Learning Program',
    institution: 'Community Youth Education Initiative',
    location: 'Multan / Punjab, Pakistan',
    dates: '01/06/2020 – 30/08/2024',
    audience: 'Secondary & Intermediate Students (up to Grade XII)',
    subjects: ['Mathematics', 'Commerce Fundamentals', 'English'],
    highlights: [
      'Independently organized and delivered free academic tuition to students up to intermediate (Grade XII) level during summer school closures, sustained across multiple consecutive years.'
    ]
  }
];

export const PROFESSIONAL_EXPERIENCE_DATA: ProfessionalExperienceItem[] = [
  {
    role: 'Assistant Finance Manager',
    organization: 'Mazcorp Engineering',
    location: 'Lahore, Pakistan',
    dates: '15/05/2026 – 20/08/2026',
    domain: 'Corporate Financial Management & Project Accounting',
    highlights: [
      'Managed project budgets, cost estimates, and cash flow; enforced cost-control measures and reviewed invoices/financial reports for accuracy and compliance.',
      'Coordinated with project managers, site teams, and procurement to align financial and operational objectives, maintaining accurate records throughout.',
      'Presented financial updates to government officials (DC, CSO) and consultants; identified and flagged financial risks to support informed decision-making.'
    ]
  },
  {
    role: 'Sharebuyback Trainee Analyst',
    organization: '2iQ Human Resource Solutions (Pvt) Ltd',
    location: 'Lahore, Pakistan',
    dates: '02/07/2025 – 24/11/2025',
    domain: 'Global Capital Markets & Equity Buyback Intelligence',
    highlights: [
      'Analyzed share buyback transactions across multiple international markets, sourcing data from annual reports, regulatory filings, and platforms including Bloomberg, Investing.com, and Yahoo Finance.',
      'Tracked tender offers and open-market repurchase programs, evaluating AGM disclosures to assess management intent and capital structure governance.',
      'Built and maintained structured Excel datasets, cross-verifying multiple international data sources to ensure rigorous analytical data integrity.'
    ]
  },
  {
    role: 'Audit & Tax Intern',
    organization: 'Federal Board of Revenue (FBR)',
    location: 'Multan, Pakistan',
    dates: '07/06/2023 – 15/08/2023',
    domain: 'Public Fiscal Administration, Auditing & Statutory Compliance',
    link: 'https://drive.google.com/drive/folders/1yyDCTQ4H5_wCNiHQD6hGuqXbk08RYaXJ?usp=drive_link',
    highlights: [
      'Assisted in audit tasks and reviewing tax documents, and helped the enforcement team with case files and data entry.',
      'Supported the human resource team in managing employee records and observed corporate tax compliance processes.'
    ]
  }
];

export const CERTIFICATIONS_DATA: CertificationItem[] = [
  {
    title: 'Foundations of Sustainability and ESG',
    issuer: 'Saïd Business School, University of Oxford (via Coursera)',
    date: '19/02/2026',
    isUniversityAuthorized: true,
    skills: ['ESG Integration', 'Sustainability Accounting', 'Corporate Governance', 'Sustainable Investment Strategies'],
    description: 'Advanced curriculum covering ESG concepts, sustainability foundations, materiality matrices, and how environmental, social, and governance factors are integrated into business and investment decision-making.'
  },
  {
    title: 'Corporate Finance Fundamentals',
    issuer: 'Corporate Finance Institute (CFI, via Coursera)',
    date: '19/02/2026',
    isUniversityAuthorized: false,
    skills: ['Capital Allocation', 'DCF Valuation Principles', 'Financial Decision-Making', 'Capital Structure'],
    description: 'Covers core corporate finance concepts including capital budgeting, cost of capital, capital structure optimization, and financial performance evaluation.'
  },
  {
    title: 'SPSS: Apply & Interpret Logistic Regression Models',
    issuer: 'EDUCBA (via Coursera)',
    date: '23/11/2025',
    isUniversityAuthorized: false,
    skills: ['Logistic Regression', 'Odds Ratios', 'SPSS Statistical Modeling', 'Model Goodness-of-Fit'],
    description: 'Applied statistical training on estimating binary/multinomial logistic regression models in SPSS and interpreting odds ratios and classification tables.'
  },
  {
    title: 'Investment Risk Management',
    issuer: 'Coursera Project Network',
    date: '06/09/2025',
    isUniversityAuthorized: false,
    credentialUrl: 'https://drive.google.com/drive/folders/1YKiuyz6Z9dPuI1pGlczVFZrpVJ09F0JU?usp=sharing',
    skills: ['Risk Assessment', 'Portfolio Risk Modeling', 'Value at Risk (VaR)', 'Scenario Analysis'],
    description: 'Project-based certification focused on measuring and managing investment portfolio risks, volatility estimation, and downside risk frameworks.'
  },
  {
    title: 'Leadvolution – Virtual Leadership Summit 2025',
    issuer: 'Certificate of Participation',
    date: '07/09/2025 – 08/09/2025',
    isUniversityAuthorized: false,
    credentialUrl: 'https://drive.google.com/file/d/1IAD409sPytf0YDbiHEhVTuRFC2PjMwOS/view?usp=drive_link',
    skills: ['Leadership Development', 'Strategic Engagement', 'Academic Communication'],
    description: 'Participated in a virtual leadership summit focused on organizational leadership development, analytical communication, and strategic engagement.'
  }
];

export const TECHNICAL_SKILLS_DATA = {
  econometrics: [
    { name: 'Panel Data Econometrics', details: 'Fixed Effects (FE), Random Effects (RE), Pooled OLS, Two-Way Fixed Effects (TWFE)' },
    { name: 'Endogeneity & Instrumental Variables', details: 'Two-Stage Least Squares (2SLS/IV), Lagged Instruments, Reverse Causality controls' },
    { name: 'Diagnostic Testing', details: 'Breusch-Pagan & Modified Wald (Heteroskedasticity), Breusch-Godfrey LM (Autocorrelation), VIF (Multicollinearity), Hausman Test' },
    { name: 'Time-Series & Asset Pricing', details: 'CAPM Single-Factor Regressions, Fama-French Multi-Factor Factor Models, Jensen\'s Alpha, Return Log-transformation' },
    { name: 'Quantile Regression', details: 'Nonlinear distributional evaluation across innovation/performance percentiles' }
  ],
  valuationAndModeling: [
    { name: 'Discounted Cash Flow (DCF / FCFF / FCFE)', details: 'Multi-stage FCFF projections, Gordon Growth terminal value, WACC estimation' },
    { name: 'Three-Statement Financial Modeling', details: 'Dynamic integration of Income Statement, Balance Sheet, and Cash Flow Statement' },
    { name: 'Scenario & Sensitivity Analysis', details: 'Bull/Base/Bear modeling, 2D sensitivity matrices (WACC vs. g)' },
    { name: 'Common-Size & Ratio Analysis', details: '14+ financial ratios across profitability, liquidity, solvency, and efficiency' },
    { name: 'Equity Research & Report Writing', details: 'Institutional-grade investment memos, catalyst identification, ESG integration' }
  ],
  softwareAndTools: [
    { name: 'STATA (Stata 15)', category: 'Statistical / Econometric', proficiency: 'Advanced', uses: 'tsset, xtset, xtreg fe/re, tabstat, tsline, estat hettest, estat bgodfrey' },
    { name: 'SPSS', category: 'Statistical / Econometric', proficiency: 'Proficient', uses: 'Linear & Logistic Regression, Descriptives, Cross-tabulations, ANOVA' },
    { name: 'Microsoft Excel', category: 'Financial Modeling', proficiency: 'Advanced', uses: 'Complex 3-statement models, Sensitivity tables, DCF workbooks, Pivot tables' },
    { name: 'Reference Managers', category: 'Academic Research', proficiency: 'Proficient', uses: 'Zotero, Mendeley, EndNote (citation styling, bibliography curation)' },
    { name: 'Document & Presentation', category: 'Publishing & Design', proficiency: 'Advanced', uses: 'Microsoft Word, Microsoft PowerPoint, Canva Academic Presentation Design' }
  ]
};

export const ACADEMIC_CITATIONS = [
  'Fama, E. F. (1970). Efficient capital markets: A review of theory and empirical work. Journal of Finance, 25(2), 383–417.',
  'Sharpe, W. F. (1964). Capital asset prices: A theory of market equilibrium under conditions of risk. Journal of Finance, 19(3), 425–442.',
  'Lintner, J. (1965). The valuation of risk assets and selection of risky investments. Review of Economics and Statistics, 47(1), 13–37.',
  'Black, F. (1972). Capital market equilibrium with restricted borrowing. Journal of Business, 45(3), 444–455.',
  'Wooldridge, J. M. (2016). Introductory econometrics: A modern approach (6th ed.). Cengage Learning.',
  'Lian, H. (2026). FinTech as a catalyst for affiliate innovation: Insights from cross-regional innovation in China. Finance Research Letters, 87, 108896.',
  'Munir, A. F., Sukor, M. E. A., & Shaharuddin, S. S. (2022). Adaptive market hypothesis: Evidence from emerging stock markets. SAGE Open, 12(1), 1–16.',
  'Saleem, A. M. et al. (2023). Regional stock market efficiency at weak form. International Journal of Economics and Financial Issues, 13(6), 63–70.',
  'Kashif, M. et al. (2023). Deciphering equity style returns: An analysis of size and value anomalies in the PSX. Heliyon, 9(8), e19022.',
  'Tauseef, S., & Dupuy, P. (2022). Pakistan: A study of market\'s returns and anomalies. Journal of Economics, Finance and Administrative Science, 27(54), 344–363.'
];
